package com.cognizant.collector.jira.beans;

import com.fasterxml.jackson.annotation.*;
import lombok.*;

@Data
public class MySelf {

    @JsonProperty("timeZone")
    private String timeZone;
    @JsonProperty("locale")
    private String locale;

}
