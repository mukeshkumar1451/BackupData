package com.cognizant.collector.jira.service;

import com.cognizant.collector.jira.beans.zephyrscale.*;
import com.cognizant.collector.jira.db.repo.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.*;

import java.util.*;

@Service
public class ZephyrScaleTestCaseService {

    @Autowired
    ZephyrScaleTestCaseRepository testcaseRepository;

    public void saveAll(List<ZephyrScaleTestCase> testCases) {
        testcaseRepository.saveAll(testCases);
    }

    public void save(ZephyrScaleTestCase testCase) {
        testcaseRepository.save(testCase);
    }
}
