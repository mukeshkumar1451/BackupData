package com.cognizant.collector.jira.beans.core;

import com.cognizant.collector.jira.util.TestCaseDeserializer;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import lombok.Data;

import java.util.List;

@Data
@JsonDeserialize(using = TestCaseDeserializer.class)
public class TestCaseDetails {
    private List<TestCase> testCaseDetails ;
    private List<String> testCaseKey;
    int totalCount;


}
