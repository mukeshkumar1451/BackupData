package com.cognizant.collector.jira.beans.zephyrscale;

import com.cognizant.collector.jira.beans.zephyrscale.testrun.*;
import com.cognizant.collector.jira.component.CommonUtilComponent;
import lombok.*;
import org.springframework.data.annotation.*;
import org.springframework.data.mongodb.core.mapping.*;

import java.util.*;

@Data
@Document(collection = "#{T(com.cognizant.collector.jira.component.CommonUtilComponent).getZephyrCollectionName()}")
public class ZephyrScaleTestRun {

    @Id
    private long id;
    private String description;
    private String type;
    private String testCaseKey;
    private String testCaseStatus;
    private Long firstFolderId;
    private String firstFolderName;
    private ExecutionSummary executionSummary;

    private String projectId;
    private String projectKey;
    private String projectName;
    private String projectCategoryId;
    private String projectCategoryName;

    private String version;
    private String folder;

    private String day7Flag = "false";
    private String day30Flag = "false";

    private String cycleKey;
    private String cycleName;
    private String cycleExecutionStatus;

    private String owner;
    private String assignedTo;
    private String userKey;

    private Date createdOn;
    private String createdBy;
    private Date plannedStartDate;
    private Date plannedEndDate;
    private Date actualStartDate;
    private Date actualEndDate;
    private String executedBy;
    private Date executionDate;
    private String updatedBy;
    private Date updatedOn;

    private long estimatedTime;
    private long executionTime;

    private long issueCount;
    private long testCaseCount;

}
