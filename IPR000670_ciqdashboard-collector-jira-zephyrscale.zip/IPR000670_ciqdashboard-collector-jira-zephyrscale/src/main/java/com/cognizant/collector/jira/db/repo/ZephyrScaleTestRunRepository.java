package com.cognizant.collector.jira.db.repo;

import com.cognizant.collector.jira.beans.zephyrscale.*;
import org.springframework.data.mongodb.repository.*;

import java.util.*;

public interface ZephyrScaleTestRunRepository extends MongoRepository<ZephyrScaleTestRun, String> {
    ZephyrScaleTestRun findFirstByProjectKeyAndFirstFolderNameOrderByExecutionDateDesc(String projectKey, String firstFolderName);
    List<ZephyrScaleTestRun> findByProjectKeyAndFirstFolderName(String projectKey, String firstFolderName);
}
