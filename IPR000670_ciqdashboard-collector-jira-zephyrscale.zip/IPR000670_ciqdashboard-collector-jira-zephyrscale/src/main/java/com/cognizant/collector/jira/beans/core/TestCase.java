package com.cognizant.collector.jira.beans.core;

import com.cognizant.collector.jira.util.TestCaseDeserializer;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import lombok.Data;

import java.util.Date;

@Data

public class TestCase {

    private String testResultKey;
    private String executionDate;
    private String linkStatusName;
    private String typeName;

}
