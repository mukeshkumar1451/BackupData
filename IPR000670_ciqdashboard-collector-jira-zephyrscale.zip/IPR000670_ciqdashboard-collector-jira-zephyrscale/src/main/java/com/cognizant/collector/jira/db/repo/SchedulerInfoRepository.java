package com.cognizant.collector.jira.db.repo;

import com.cognizant.collector.jira.beans.metadata.*;
import org.springframework.data.mongodb.repository.*;

import java.util.*;

public interface SchedulerInfoRepository extends MongoRepository<SchedulerInfo, String> {
    Optional<SchedulerInfo> findFirstByToolName(String toolName);
}
