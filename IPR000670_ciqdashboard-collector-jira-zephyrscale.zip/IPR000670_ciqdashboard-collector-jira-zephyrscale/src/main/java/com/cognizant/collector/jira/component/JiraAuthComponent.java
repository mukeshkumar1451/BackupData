package com.cognizant.collector.jira.component;

import com.cognizant.collector.jira.auto.*;
import lombok.extern.slf4j.*;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.*;

import java.net.*;
import java.time.*;
import java.util.Objects;
import java.util.stream.*;

@Component
@Slf4j
public class JiraAuthComponent {

    @Autowired
    WebDriver webDriver;

    @Autowired
    LoginPage loginPage;

    @Autowired
    CommonUtilComponent utilComponent;

    @Value("${jiraServer.url}")
    private URL jiraServerUrl;

    @Value("${jiraServer.username}")
    private String jiraServerUserEmail;

    @Value("${jiraServer.password}")
    private String jiraServerPassword;

    private String cookies;
    private boolean isLoggedIn = false;

    public void login() {
        log.info("Logging in to JIRA!");
        if(isLoggedIn) {
            refresh();
            return;
        }
        webDriver.navigate().to(jiraServerUrl);
        enterCredentials();

        this.isLoggedIn = true;
    }

    private void enterCredentials() {
        try {
          //  loginPage.login(jiraServerUserEmail, utilComponent.decodeBase64String(jiraServerPassword));
            loginPage.login(jiraServerUserEmail, jiraServerPassword);
            new WebDriverWait(webDriver, Duration.ofSeconds(20)).until(
                    webDriver -> ((JavascriptExecutor) webDriver).executeScript("return document.readyState").equals("complete"));
            this.setCookies();
        } catch (NoSuchElementException e) {
            log.warn("Error occurred while accessing login page elements", e);
        }
    }

    public void refresh() {
        webDriver.navigate().refresh();
        new WebDriverWait(webDriver, Duration.ofSeconds(20)).until(
                webDriver -> ((JavascriptExecutor) webDriver).executeScript("return document.readyState").equals("complete"));
        if(Objects.equals(loginPage.getTitle(), "SSO Login")) {
            enterCredentials();
        }
    }

    private void setCookies() {
        this.cookies = webDriver.manage().getCookies().stream()
                .map(cookie -> webDriver.manage().getCookieNamed(cookie.getName()).toString())
                .collect(Collectors.joining(";"));
    }

    public String getCookies() {
        return this.cookies;
    }

    public void logout() {
        log.info("Logging out of JIRA!");
        this.cookies = null;

    }

}