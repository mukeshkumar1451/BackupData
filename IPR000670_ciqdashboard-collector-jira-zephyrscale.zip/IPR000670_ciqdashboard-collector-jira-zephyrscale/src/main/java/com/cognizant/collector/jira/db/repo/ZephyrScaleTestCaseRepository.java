package com.cognizant.collector.jira.db.repo;

import com.cognizant.collector.jira.beans.zephyrscale.*;
import org.springframework.data.mongodb.repository.*;

public interface ZephyrScaleTestCaseRepository extends MongoRepository<ZephyrScaleTestCase, String> {
}
