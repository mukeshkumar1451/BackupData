package com.cts.idashboard.services.metricservice.data;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;
import org.json.simple.JSONArray;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import java.time.Instant;
import java.util.List;


@JsonInclude(JsonInclude.Include.NON_NULL)
@Document(collection = "source_metrics")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class MetricResults<T> extends BaseModel {
    @Id
    private String id;
    private String toolType;
    private String metricName;
    private double metricValue;
    private String projectName;
    private String dashboardName;
    private String pageName;
    private String itemId;
    private String customFunction;
    private String customFunctionName;
    private String grouping;
    private String groupBy;
    private String groupValue;

    private Instant lastCalculatedDate;
    private JSONArray groupedResult;

    private String trending;
    private String trendBy;
    private String trendingField;
    private int trendCount;
    private String lobId;
    private String orgId;
    // private JSONArray groupedResult;
    // private JSONArray trendResult;
   // private JSONArray metricValues;
    private JSONArray metricValues;
    //@Field("metricValues")
    private List<TrendingMetric> trendingMetricValues;

}
