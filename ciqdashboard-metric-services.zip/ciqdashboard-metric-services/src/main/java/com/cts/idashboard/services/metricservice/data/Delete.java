//package com.cts.idashboard.services.metricservice.data;
//
//import lombok.Data;
//
//@Data
//public class Delete {
//
//    private String parentId;
//    private String parentType;
//
//}
