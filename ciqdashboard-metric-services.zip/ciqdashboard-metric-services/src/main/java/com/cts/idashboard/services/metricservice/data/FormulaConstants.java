package com.cts.idashboard.services.metricservice.data;

public class FormulaConstants {
    public final static String countAnd="countBy";
}
