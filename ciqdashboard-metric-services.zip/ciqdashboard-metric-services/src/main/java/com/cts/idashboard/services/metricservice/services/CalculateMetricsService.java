package com.cts.idashboard.services.metricservice.services;

import com.cts.idashboard.services.metricservice.data.*;
import com.cts.idashboard.services.metricservice.data.project.CIQDashboardProject;
import com.cts.idashboard.services.metricservice.repos.*;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class CalculateMetricsService {

    @Autowired
    DashboardRepository dashboardRepository;

    @Autowired
    CalculateZephyrMetrics calculateZephyrMetrics;

    @Autowired
    CalculateRallyMetrics calculateRallyMetrics;

    @Autowired
    CalculateBotsDefectsMetrics calculateBotsDefectsMetrics;

    @Autowired
    CalculateServiceNowIncidents calculateServiceNowIncidents;

    @Autowired
    CalculateJiraMetrics calculateJiraMetrics;

    @Autowired
    CalculateALMMetric calculateALMMetricService;

    @Autowired
    CalculateXrayMetrics calculateXrayMetrics;

    @Autowired
    CalculateJenkinsMetrics calculateJenkinsMetrics;


    @Autowired
    CalculateGitMetrics calculateGitMetrics;

    @Autowired
    CalculateZephyrScaleMetrics calculateZephyrScaleMetrics;

    @Autowired
    MetricsRepository metricsRepository;

    @Autowired
    MetricConfigRepository metricConfigRepository;

    @Autowired
    SchedulerRunsRepository schedulerRunsRepository;

    @Autowired
    CIQDashboardProjectRepository projectRepository;

    @Autowired
    LOBRepository lobRepository;

    @Autowired
    OrganizationRepository organizationRepository;

    public MetricResponse calculateMetrics(ProjectMetric projectMetric) throws Exception {

        Optional<Dashboard> dashboard = dashboardRepository.findByProjectNameAndName(projectMetric.getProjectName(), projectMetric.getDashboardName());

        CIQDashboardProject dashboardProject = projectRepository.findByName(projectMetric.getProjectName());
        Optional<LOB> lob = lobRepository.findByLobName(projectMetric.getProjectName());
        Optional<Organization> organization = organizationRepository.findByOrganizationName(projectMetric.getProjectName());


        List<String> jiraProjectNames = new ArrayList<>();
        List<String> almProjectNames = new ArrayList<>();
        List<String> zephyrProjectNames = new ArrayList<>();
        List<String> zephyrScaleProjectNames = new ArrayList<>();
        List<String> botProjectNames = new ArrayList<>();
        List<String> xrayProjectNames = new ArrayList<>();
        List<String> jenkinProjectNames = new ArrayList<>();
        List<String> gitProjectNames = new ArrayList<>();
        List<String> rallyProjectNames = new ArrayList<>();
        List<String> serviceNowProjectNames = new ArrayList<>();


        String lobId = null;
        String orgId = null;
        String levelLayer = null;
        List<CIQDashboardProject> ciqDashboardProjects = null;

        if(dashboardProject != null){
            levelLayer = "project";
        }
        else if(!lob.isEmpty()){
            levelLayer = "lob";
            lobId = lob.get().getId();
            ciqDashboardProjects = (List<CIQDashboardProject>) projectRepository.findByLobId(lobId);
        }
        else if(!organization.isEmpty()){
            levelLayer = "org";
            orgId = organization.get().getId();
            ciqDashboardProjects = (List<CIQDashboardProject>) projectRepository.findByOrgId(orgId);
        }

        System.out.println("Layer is "+levelLayer);
        if(levelLayer!="project") {
            if(ciqDashboardProjects!=null || ciqDashboardProjects.size()>0){
                for (CIQDashboardProject ciqDashboardProject : ciqDashboardProjects) {

                if (ciqDashboardProject.getSourceTools() != null) {
                    for (int i = 0; i < ciqDashboardProject.getSourceTools().size(); i++) {
                        Map<String, List<String>> obj = (Map<String, List<String>>) ciqDashboardProject.getSourceTools().get(i);

                        if (String.valueOf(obj.get("toolName")).toLowerCase().contains("jira")) {
                            projectMetric.setJiraProjects(obj.get("projectNames"));
                            jiraProjectNames.addAll(obj.get("projectNames"));
                        }
                        if (String.valueOf(obj.get("toolName")).toLowerCase().contains("alm")) {
                            projectMetric.setAlmProjects(obj.get("projectNames"));
                            almProjectNames.addAll(obj.get("projectNames"));
                        }
                        if (String.valueOf(obj.get("toolName")).toLowerCase().contains("zephyr") && !String.valueOf(obj.get("toolName")).toLowerCase().contains("zephyrscale")) {
                            projectMetric.setZephyrProjects(obj.get("projectNames"));
                            zephyrProjectNames.addAll(obj.get("projectNames"));
                        }
                        if (String.valueOf(obj.get("toolName")).toLowerCase().contains("rally")) {
                            projectMetric.setRallyProjects(obj.get("projectNames"));
                            rallyProjectNames.addAll(obj.get("projectNames"));
                        }
                        if (String.valueOf(obj.get("toolName")).toLowerCase().contains("service")) {
                            projectMetric.setServiceNowIncidentProjects(obj.get("projectNames"));
                            serviceNowProjectNames.addAll(obj.get("projectNames"));
                        }
                        if (String.valueOf(obj.get("toolName")).toLowerCase().contains("bots")) {
                            projectMetric.setBotsDefectsProjects(obj.get("projectNames"));
                            botProjectNames.addAll(obj.get("projectNames"));
                        }
                        if (String.valueOf(obj.get("toolName")).toLowerCase().contains("xray")) {
                            projectMetric.setXrayProjects(obj.get("projectNames"));
                            xrayProjectNames.addAll(obj.get("projectNames"));
                        }
                        if (String.valueOf(obj.get("toolName")).toLowerCase().contains("jenkins")) {
                            projectMetric.setJenkinsProjects(obj.get("projectNames"));
                            jenkinProjectNames.addAll(obj.get("projectNames"));
                        }
                        if (String.valueOf(obj.get("toolName")).toLowerCase().contains("git")) {
                            projectMetric.setGitProjects(obj.get("projectNames"));
                            gitProjectNames.addAll(obj.get("projectNames"));
                        }
                        if (String.valueOf(obj.get("toolName")).toLowerCase().contains("zephyrscale")) {
                            projectMetric.setZephyrProjects(obj.get("projectNames"));
                            zephyrScaleProjectNames.addAll(obj.get("projectNames"));
                        }
                    }
                }
                }
            }
            System.out.println("CIQ Dashboard projects linked to org or log: "+ciqDashboardProjects);

            System.out.println("Total Jira projects that are linked to the org or lob projects "+jiraProjectNames);
            System.out.println("Total Alm projects that are linked to the org or lob projects "+almProjectNames);
            System.out.println("Total Zephyr projects that are linked to the org or lob projects "+zephyrProjectNames);
            System.out.println("Total Zephyr Scale projects that are linked to the org or lob projects "+zephyrScaleProjectNames);
            System.out.println("Total Bot projects that are linked to the org or lob projects "+botProjectNames);
            System.out.println("Total Rally projects that are linked to the org or lob projects "+rallyProjectNames);
            System.out.println("Total Service now projects that are linked to the org or lob projects "+serviceNowProjectNames);
            System.out.println("Total Jenkins projects that are linked to the org or lob projects "+jenkinProjectNames);
            System.out.println("Total Git projects that are linked to the org or lob projects "+gitProjectNames);
            System.out.println("Total Xray projects that are linked to the org or lob projects "+xrayProjectNames);
        }


        if (dashboard.isPresent()) {
            System.out.println("Dashboard exists with the name : "+dashboard.get().getName());

            IDPageConfig selectedPage = dashboard.get().getPages().stream()
                    .filter(page -> projectMetric.getPageName().equals(page.getName()))
                    .findAny()
                    .orElseThrow(() -> new Exception("Page not found!!"));

            System.out.println("Page exists with name : "+ selectedPage.getName());
            List<IDItemConfig> metricItemList = new ArrayList<>();
            for (IDItemConfig item : selectedPage.getItems()) {
                if ("derived".equalsIgnoreCase(item.getMetricCategory())) {
                    metricItemList.add(item);
                }
            }

            Dashboard dashboardResult = dashboard.get();
            List<MetricResults> metrics = new ArrayList<>();
            MetricResponse metricResponse = new MetricResponse();

            if(levelLayer == "project"){

                CIQDashboardProject project = projectRepository.findByName(projectMetric.getProjectName());
                System.out.println("@@@@@@@@@@@@@@@ Project : " + project);

                if (project.getSourceTools() != null) {
                    for (int i = 0; i < project.getSourceTools().size(); i++) {
                        Map<String, List<String>> obj = (Map<String, List<String>>) project.getSourceTools().get(i);
                        if (String.valueOf(obj.get("toolName")).toLowerCase().contains("jira")) {
                            projectMetric.setJiraProjects(obj.get("projectNames"));
                        }
                        if (String.valueOf(obj.get("toolName")).toLowerCase().contains("alm")) {
                            projectMetric.setAlmProjects(obj.get("projectNames"));
                        }
                        if (String.valueOf(obj.get("toolName")).toLowerCase().contains("zephyr") && !String.valueOf(obj.get("toolName")).toLowerCase().contains("zephyrscale")) {
                            projectMetric.setZephyrProjects(obj.get("projectNames"));
                        }
                        if (String.valueOf(obj.get("toolName")).toLowerCase().contains("rally")) {
                            projectMetric.setRallyProjects(obj.get("projectNames"));
                        }
                        if (String.valueOf(obj.get("toolName")).toLowerCase().contains("service")) {
                            projectMetric.setServiceNowIncidentProjects(obj.get("projectNames"));
                        }
                        if (String.valueOf(obj.get("toolName")).toLowerCase().contains("bots")) {
                            projectMetric.setBotsDefectsProjects(obj.get("projectNames"));
                        }
                        if (String.valueOf(obj.get("toolName")).toLowerCase().contains("xray")) {
                            projectMetric.setXrayProjects(obj.get("projectNames"));
                        }
                        if (String.valueOf(obj.get("toolName")).toLowerCase().contains("jenkins")) {
                            projectMetric.setJenkinsProjects(obj.get("projectNames"));
                        }
                        if (String.valueOf(obj.get("toolName")).toLowerCase().contains("git")) {
                            projectMetric.setGitProjects(obj.get("projectNames"));
                        }
                        if (String.valueOf(obj.get("toolName")).toLowerCase().contains("zephyrscale")) {
                            projectMetric.setZephyrScaleProjects(obj.get("projectNames"));
                        }
                    }
                }
            }

            System.out.println("ProjectMetric --------------- " + projectMetric);
            for (IDItemConfig item : metricItemList) {

                Optional<MetricConfig> metricConfig = metricConfigRepository.findByMetricName(item.getMetricName());

                if (metricConfig.isPresent()) {
                    System.out.println("metricConfig --- *** --- "+metricConfig.get());

                    // Set custom function field values
                    projectMetric.setCustomFunction(metricConfig.get().getCustomFunction());
                    projectMetric.setCustomFunctionName(metricConfig.get().getCustomFunctionName());

                    // Set grouping calculation field values
                    projectMetric.setGroupBy(metricConfig.get().getGroupBy());
                    projectMetric.setGrouping(metricConfig.get().getGrouping());
                    projectMetric.setGroupValue(metricConfig.get().getGroupValue());

                    // Set trending calculation field values
                    projectMetric.setTrendBy(metricConfig.get().getTrendBy());
                    projectMetric.setTrending(metricConfig.get().getTrending());
                    projectMetric.setTrendingField(metricConfig.get().getTrendingField());
                    projectMetric.setTrendCount(metricConfig.get().getTrendCount());

                    // Set metric formula calculation field values
                    projectMetric.setFormula(metricConfig.get().getFormula());
                    projectMetric.setFormulaParams(metricConfig.get().getFormulaParams());

                    System.out.println("ProjectMetric --- *** --- " + projectMetric);
                    System.out.println("Metric tool ** "+metricConfig.get().getToolType().toLowerCase());

                    switch (metricConfig.get().getToolType().toLowerCase()) {
                        case "jira":
                            System.out.println("***@@@ JIRA @@@***");
                            try {
                                System.out.println("Jira projects linked with lob or org are :"+jiraProjectNames);
                                if(levelLayer!="project"){
                                    if(jiraProjectNames.size()>0)
                                        projectMetric.setJiraProjects(jiraProjectNames.stream().distinct().collect(Collectors.toList()));
                                    else
                                        projectMetric.setJiraProjects(null);
                                }
                                projectMetric.setItemId(item.getId());
                                projectMetric.setPageName(selectedPage.getName());
                                boolean isRequired = isCalculationRequired(item.getMetricName(), projectMetric, "Jira");
                                if (isRequired) {
                                    MetricResults metricsResult = calculateJiraMetrics.calculateJiraMetrics(item.getMetricName(), projectMetric,"JiraIssue", lobId, orgId);
                                    metrics.add(metricsResult);
                                    dashboardResult.setMetrics(metrics);
                                    metricResponse.setMessage("Calculation done with new data");
                                    metricResponse.setData(dashboardResult);
                                    metricResponse.setCalculated(true);
                                } else {
                                    metricResponse.setMessage("No Calculation required");
                                    metricResponse.setData(null);
                                    metricResponse.setCalculated(false);
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                                metricResponse.setMessage("Some Exception occurred");
                                metricResponse.setData(null);
                                metricResponse.setCalculated(false);
                            }
                            break;
                        case "alm":
                            System.out.println("***@@@ ALM @@@***");
                            try {
                                System.out.println("ALM projects linked with lob or org are :"+almProjectNames);
                                if(levelLayer!="project"){
                                    if(almProjectNames.size()>0)
                                        projectMetric.setAlmProjects(almProjectNames.stream().distinct().collect(Collectors.toList()));
                                    else
                                        projectMetric.setAlmProjects(null);
                                }
                                projectMetric.setItemId(item.getId());
                                projectMetric.setPageName(selectedPage.getName());
                                boolean isRequired = isCalculationRequired(item.getMetricName(), projectMetric, "ALM");
                                if (isRequired) {
                                    MetricResults metricsResult = calculateALMMetricService.calculateALMMetric(item.getMetricName(), projectMetric,"SourceAlmAssets", lobId, orgId);
                                    metrics.add(metricsResult);
                                    dashboardResult.setMetrics(metrics);
                                    metricResponse.setMessage("Calculation done with new data");
                                    metricResponse.setData(dashboardResult);
                                    metricResponse.setCalculated(true);
                                } else {
                                    metricResponse.setMessage("No Calculation required");
                                    metricResponse.setData(null);
                                    metricResponse.setCalculated(false);
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                                metricResponse.setMessage("Some Exception occurred " + e.getStackTrace());
                                metricResponse.setData(null);
                                metricResponse.setCalculated(false);
                            }
                            break;
                        case "zephyr":
                            try {
                                System.out.println("Zephyr projects linked with lob or org are :"+zephyrProjectNames);
                                if(levelLayer!="project"){
                                    if(zephyrProjectNames.size()>0)
                                        projectMetric.setZephyrProjects(zephyrProjectNames.stream().distinct().collect(Collectors.toList()));
                                    else
                                        projectMetric.setZephyrProjects(null);
                                }
                                projectMetric.setItemId(item.getId());
                                projectMetric.setPageName(selectedPage.getName());
                                boolean isRequired = isCalculationRequired(item.getMetricName(), projectMetric, "Zephyr");
                                if (isRequired) {
                                    MetricResults metricsResult = calculateZephyrMetrics.calculateZephyrMetrics(item.getMetricName(), projectMetric,"SourceZephyrData", lobId, orgId);
                                    metrics.add(metricsResult);
                                    dashboardResult.setMetrics(metrics);
                                    metricResponse.setMessage("Calculation done with new data");
                                    metricResponse.setData(dashboardResult);
                                    metricResponse.setCalculated(true);
                                } else {
                                    metricResponse.setMessage("No Calculation required");
                                    metricResponse.setData(null);
                                    metricResponse.setCalculated(false);
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                                metricResponse.setMessage("Some Exception occurred");
                                metricResponse.setData(null);
                                metricResponse.setCalculated(false);
                            }
                            break;
                        case "rally":
                            try {
                                System.out.println("Rally projects linked with lob or org are :"+rallyProjectNames);
                                if(levelLayer!="project"){
                                    if(rallyProjectNames.size()>0)
                                        projectMetric.setRallyProjects(rallyProjectNames.stream().distinct().collect(Collectors.toList()));
                                    else
                                        projectMetric.setRallyProjects(null);
                                }
                                projectMetric.setItemId(item.getId());
                                projectMetric.setPageName(selectedPage.getName());
                                boolean isRequired = isCalculationRequired(item.getMetricName(), projectMetric, "Rally");
                                if (isRequired) {
                                    MetricResults metricsResult = calculateRallyMetrics.calculateRallyMetrics(item.getMetricName(), projectMetric,"SourceRallyData", lobId, orgId);
                                    metrics.add(metricsResult);
                                    dashboardResult.setMetrics(metrics);
                                    metricResponse.setMessage("Calculation done with new data");
                                    metricResponse.setData(dashboardResult);
                                    metricResponse.setCalculated(true);
                                } else {
                                    metricResponse.setMessage("No Calculation required");
                                    metricResponse.setData(null);
                                    metricResponse.setCalculated(false);
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                                metricResponse.setMessage("Some Exception occurred");
                                metricResponse.setData(null);
                                metricResponse.setCalculated(false);
                            }
                            break;
                        case "git":
                            try {
                                System.out.println("Git projects linked with lob or org are :"+gitProjectNames);
                                if(levelLayer!="project"){
                                    if(gitProjectNames.size()>0)
                                        projectMetric.setGitProjects(gitProjectNames.stream().distinct().collect(Collectors.toList()));
                                    else
                                        projectMetric.setGitProjects(null);
                                }
                                projectMetric.setItemId(item.getId());
                                projectMetric.setPageName(selectedPage.getName());
                                boolean isRequired = isCalculationRequired(item.getMetricName(), projectMetric, "Git");
                                if (isRequired) {
                                    MetricResults metricsResult = calculateGitMetrics.calculateGitMetrics(item.getMetricName(), projectMetric,"SourceGitData", lobId, orgId);
                                    metrics.add(metricsResult);
                                    dashboardResult.setMetrics(metrics);
                                    metricResponse.setMessage("Calculation done with new data");
                                    metricResponse.setData(dashboardResult);
                                    metricResponse.setCalculated(true);
                                } else {
                                    metricResponse.setMessage("No Calculation required");
                                    metricResponse.setData(null);
                                    metricResponse.setCalculated(false);
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                                metricResponse.setMessage("Some Exception occurred");
                                metricResponse.setData(null);
                                metricResponse.setCalculated(false);
                            }
                            break;
                        case "service":
                            try {
                                System.out.println("ServiceNow projects linked with lob or org are :"+serviceNowProjectNames);
                                if(levelLayer!="project"){
                                    if(serviceNowProjectNames.size()>0)
                                        projectMetric.setServiceNowIncidentProjects(serviceNowProjectNames.stream().distinct().collect(Collectors.toList()));
                                    else
                                        projectMetric.setServiceNowIncidentProjects(null);
                                }
                                projectMetric.setItemId(item.getId());
                                projectMetric.setPageName(selectedPage.getName());
                                boolean isRequired = isCalculationRequired(item.getMetricName(), projectMetric, "Rally");
                                if (isRequired) {
                                    MetricResults metricsResult = calculateServiceNowIncidents.calculateServiceNowIncidentMetrics(item.getMetricName(), projectMetric,"SourceServiceNowIncidents", lobId, orgId);
                                    metrics.add(metricsResult);
                                    dashboardResult.setMetrics(metrics);
                                    metricResponse.setMessage("Calculation done with new data");
                                    metricResponse.setData(dashboardResult);
                                    metricResponse.setCalculated(true);
                                } else {
                                    metricResponse.setMessage("No Calculation required");
                                    metricResponse.setData(null);
                                    metricResponse.setCalculated(false);
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                                metricResponse.setMessage("Some Exception occurred");
                                metricResponse.setData(null);
                                metricResponse.setCalculated(false);
                            }
                            break;
                        case "bots":
                            try {
                                System.out.println("Bot projects linked with lob or org are :"+botProjectNames);
                                if(levelLayer!="project"){
                                    if(botProjectNames.size()>0)
                                        projectMetric.setBotsDefectsProjects(botProjectNames.stream().distinct().collect(Collectors.toList()));
                                    else
                                        projectMetric.setBotsDefectsProjects(null);
                                }
                                projectMetric.setItemId(item.getId());
                                projectMetric.setPageName(selectedPage.getName());
                                boolean isRequired = isCalculationRequired(item.getMetricName(), projectMetric, "bots");
                                if (isRequired) {
                                    MetricResults metricsResult = calculateBotsDefectsMetrics.calculateBotsMetrics(item.getMetricName(), projectMetric,"SourceBotsDefects", lobId, orgId);
                                    metrics.add(metricsResult);
                                    dashboardResult.setMetrics(metrics);
                                    metricResponse.setMessage("Calculation done with new data");
                                    metricResponse.setData(dashboardResult);
                                    metricResponse.setCalculated(true);
                                } else {
                                    metricResponse.setMessage("No Calculation required");
                                    metricResponse.setData(null);
                                    metricResponse.setCalculated(false);
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                                metricResponse.setMessage("Some Exception occurred");
                                metricResponse.setData(null);
                                metricResponse.setCalculated(false);
                            }

                            break;
                        case "xray":
                            try {
                                System.out.println("XRay projects linked with lob or org are :"+xrayProjectNames);
                                if(levelLayer!="project"){
                                    if(xrayProjectNames.size()>0)
                                        projectMetric.setXrayProjects(xrayProjectNames.stream().distinct().collect(Collectors.toList()));
                                    else
                                        projectMetric.setXrayProjects(null);
                                }
                                projectMetric.setItemId(item.getId());
                                projectMetric.setPageName(selectedPage.getName());
                                boolean isRequired = isCalculationRequired(item.getMetricName(), projectMetric, "xray");
                                if (isRequired) {
                                    MetricResults metricsResult = calculateXrayMetrics.calculateXrayMetrics(item.getMetricName(), projectMetric,"SourceXrayTests", lobId, orgId);
                                    metrics.add(metricsResult);
                                    dashboardResult.setMetrics(metrics);
                                    metricResponse.setMessage("Calculation done with new data");
                                    metricResponse.setData(dashboardResult);
                                    metricResponse.setCalculated(true);
                                } else {
                                    metricResponse.setMessage("No Calculation required");
                                    metricResponse.setData(null);
                                    metricResponse.setCalculated(false);
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                                metricResponse.setMessage("Some Exception occurred");
                                metricResponse.setData(null);
                                metricResponse.setCalculated(false);
                            }

                            break;
                        case "jenkins":
                            try {
                                System.out.println("Jenkin projects linked with lob or org are :"+jenkinProjectNames);
                                if(levelLayer!="project"){
                                    if(jenkinProjectNames.size()>0)
                                        projectMetric.setJenkinsProjects(jenkinProjectNames.stream().distinct().collect(Collectors.toList()));
                                    else
                                        projectMetric.setJenkinsProjects(null);
                                }
                                projectMetric.setItemId(item.getId());
                                projectMetric.setPageName(selectedPage.getName());
                                boolean isRequired = isCalculationRequired(item.getMetricName(), projectMetric, "jenkins");
                                if (isRequired) {
                                    MetricResults metricsResult = calculateJenkinsMetrics.calculateJenkinsMetrics(item.getMetricName(), projectMetric,"SourceJenkinsBuild", lobId, orgId);
                                    metrics.add(metricsResult);
                                    dashboardResult.setMetrics(metrics);
                                    metricResponse.setMessage("Calculation done with new data");
                                    metricResponse.setData(dashboardResult);
                                    metricResponse.setCalculated(true);
                                } else {
                                    metricResponse.setMessage("No Calculation required");
                                    metricResponse.setData(null);
                                    metricResponse.setCalculated(false);
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                                metricResponse.setMessage("Some Exception occurred");
                                metricResponse.setData(null);
                                metricResponse.setCalculated(false);
                            }

                            break;
                        case "zephyrscale":
                            System.out.println("***@@@ ZEPHYR SCALE @@@***");
                            try {
                                System.out.println("Zephyr Scale projects linked with lob or org are :"+zephyrScaleProjectNames);
                                if(levelLayer!="project"){
                                    if(zephyrScaleProjectNames.size()>0)
                                        projectMetric.setZephyrScaleProjects(zephyrScaleProjectNames.stream().distinct().collect(Collectors.toList()));
                                    else
                                        projectMetric.setZephyrScaleProjects(null);
                                }
                                projectMetric.setItemId(item.getId());
                                projectMetric.setPageName(selectedPage.getName());
                                boolean isRequired = isCalculationRequired(item.getMetricName(), projectMetric, "ZephyrScale");
                                if (isRequired) {
                                    MetricResults metricsResult = calculateZephyrScaleMetrics.calculateZephyrScaleMetrics(item.getMetricName(), projectMetric,"SourceZephyrScaleData", lobId, orgId);
                                    metrics.add(metricsResult);
                                    dashboardResult.setMetrics(metrics);
                                    metricResponse.setMessage("Calculation done with new data");
                                    metricResponse.setData(dashboardResult);
                                    metricResponse.setCalculated(true);
                                } else {
                                    metricResponse.setMessage("No Calculation required");
                                    metricResponse.setData(null);
                                    metricResponse.setCalculated(false);
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                                metricResponse.setMessage("Some Exception occurred");
                                metricResponse.setData(null);
                                metricResponse.setCalculated(false);
                            }
                            break;
                        default:
                            System.out.println("No Tool found with name *** "+metricConfig.get().getToolType().toLowerCase());
                    }
                }
            }
            System.out.println();
            return metricResponse;
        } else {
            throw new Exception("dashboard not exists");
        }
    }

    public JSONObject getLastCalculatedMetricsForTool(String projectName, String dashboardName, String pageName) throws Exception {

        JSONObject calculatedMetrics = new JSONObject();
        List<CollectorRunScheduler> collectorRunSchedulers = schedulerRunsRepository.findAll();
        List<MetricResults> metricResults = metricsRepository.findByProjectNameAndDashboardNameAndPageName(projectName, dashboardName, pageName);

        if (!collectorRunSchedulers.isEmpty()) {
            calculatedMetrics.put("toolTypes", collectorRunSchedulers);
        } else {
            throw new Exception("Collector run for tools not found");
        }


        if (!metricResults.isEmpty()) {
//            List<String> lastCalculatedMetrics = metricResults.stream()
//                    .flatMap(p -> Stream.of("toolName : "+p.getToolType(),"dashboardName : "+ p.getDashboardName(), "lastCalculated : "+p.getLastCalculatedDate().toString()))
//                    .collect(Collectors.toList());
            List<JSONObject> lastCalculatedMetricsList = new ArrayList<>();
            for (MetricResults res : metricResults) {
                JSONObject calculatedMetricObj = new JSONObject();
                calculatedMetricObj.put("toolName", res.getToolType());
                calculatedMetricObj.put("dashboardName", res.getDashboardName());
                calculatedMetricObj.put("lastCalculated", res.getLastCalculatedDate());
                calculatedMetricObj.put("pageName", res.getPageName());
                calculatedMetricObj.put("projectName", res.getProjectName());

                lastCalculatedMetricsList.add(calculatedMetricObj);
            }
            calculatedMetrics.put("lastCalculatedDate", lastCalculatedMetricsList);
        } else {
            calculatedMetrics.put("lastCalculated", "");
        }

        System.out.println("calculatedMetrics --- " + calculatedMetrics);
        return calculatedMetrics;

    }

    public boolean isCalculationRequired(String metricName, ProjectMetric projectMetric, String toolName) {
        System.out.println("metricName - " + metricName + " - dashboardName - " + projectMetric.getDashboardName() + " - itemId - " + projectMetric.getItemId());
        Optional<MetricResults> metricResults = metricsRepository.findByMetricNameAndDashboardNameAndItemId(metricName, projectMetric.getDashboardName(), projectMetric.getItemId());
        Optional<CollectorRunScheduler> collectorRunScheduler = schedulerRunsRepository.findByToolName(toolName);

        boolean requireCalculation = true;
        if (collectorRunScheduler.isPresent() && metricResults.isPresent()) {
            System.out.println(metricResults.get() + " ^^^^^^ " + collectorRunScheduler.get());

            Instant lastCollectionUpdated = collectorRunScheduler.get().getLastUpdatedDate();
            Instant lastMetricCalculated = metricResults.get().getLastCalculatedDate();

            System.out.println("Check metric calculation happened before or after the updated collections");
            System.out.println("last collections updated "+ lastCollectionUpdated);
            System.out.println("last metric calculated "+ lastMetricCalculated);

            requireCalculation = lastCollectionUpdated.isAfter(lastMetricCalculated);

        } else if (!collectorRunScheduler.isPresent()) {
            System.out.println("collectorRunScheduler is not present for the metric tool- " + toolName);
            requireCalculation = false;

        } else if (!metricResults.isPresent()) {
            System.out.println("metricResults present : " + metricResults.isPresent());
            requireCalculation = true;
        }
        System.out.println("Is calculation required : "+ requireCalculation);
        return requireCalculation;
    }

}
