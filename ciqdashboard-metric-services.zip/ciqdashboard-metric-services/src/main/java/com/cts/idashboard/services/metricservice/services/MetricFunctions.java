package com.cts.idashboard.services.metricservice.services;

import com.cts.idashboard.services.metricservice.data.ProjectMetric;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Component;

import java.util.*;

import static org.springframework.data.mongodb.core.aggregation.Aggregation.*;

@Component
public class MetricFunctions {

    @Autowired
    MongoOperations mongoOperation;

    public long count(String className, Set<Map.Entry<String, String>> valueSet, ProjectMetric projectMetric, String isTrending, String isGrouping, Date startDate, Date endDate, String distinctValue) throws Exception {

        Class collectionClass = Class.forName("com.cts.idashboard.services.metricservice.data." + className);

        Query query = new Query();
        String isProjectsEmpty = "Yes";

        Criteria criteria = null;
        for (Map.Entry<String, String> val : valueSet) {
            System.out.println("Value map -- *** -- " + String.valueOf(val.getValue()));

            if (val.getKey().equals("collection")) {
                collectionClass = Class.forName("com.cts.idashboard.services.metricservice.data." + String.valueOf(val.getValue()));
            }
        }

        // Applying project filter criteria
        criteria = projectFilter(collectionClass, projectMetric);
        if (criteria != null) {
            System.out.println("Project Filter Criteria is not null");
            if(!(isGrouping=="Yes" && projectMetric.getGroupBy().equals("projectName"))) {
                query.addCriteria(criteria);
                System.out.println("Project filter applied");
            }
            else{
                System.out.println("Project filter not applied");
            }
            isProjectsEmpty = "No";
        }

        // Applying trendBy or GroupBy criteria
        if (isGrouping == "No" && isTrending == "Yes") {
            criteria = Criteria.where(projectMetric.getTrendBy()).gte(startDate).lte(endDate);
            query.addCriteria(criteria);
        } else if (isGrouping == "Yes" && isTrending == "No") {
            criteria = Criteria.where(projectMetric.getGroupBy()).in(distinctValue);
            query.addCriteria(criteria);
        }

        Long valKey = 0l;
        if(isProjectsEmpty == "No")
            valKey = mongoOperation.count(query, collectionClass);
        System.out.println("Count value * "+ valKey);
        return valKey;
    }

    public long countAnd(String className, Set<Map.Entry<String, String>> valueSet, ProjectMetric projectMetric, String isTrending, String isGrouping, Date startDate, Date endDate, String distinctValue) throws Exception {

        Class collectionClass = Class.forName("com.cts.idashboard.services.metricservice.data." + className);

        Query query = new Query();
        String isProjectsEmpty = "Yes";

        Criteria criteria = null;
        for (Map.Entry<String, String> val : valueSet) {
            System.out.println("Value map -- *** -- " + String.valueOf(val.getValue()));

            if (val.getKey().equals("collection")) {
                collectionClass = Class.forName("com.cts.idashboard.services.metricservice.data." + String.valueOf(val.getValue()));
            } else {
                criteria = Criteria.where(val.getKey()).is(val.getValue());
                query.addCriteria(criteria);
            }
        }

        // Applying project filter criteria
        criteria = projectFilter(collectionClass, projectMetric);
        if (criteria != null) {
            System.out.println("Project Filter Criteria is not null");
            if(!(isGrouping=="Yes" && projectMetric.getGroupBy().equals("projectName"))) {
                query.addCriteria(criteria);
                System.out.println("Project filter applied");
            }
            else{
                System.out.println("Project filter not applied");
            }
            isProjectsEmpty = "No";
        }

        // Applying trendBy or GroupBy criteria
        if (isGrouping == "No" && isTrending == "Yes") {
            criteria = Criteria.where(projectMetric.getTrendBy()).gte(startDate).lte(endDate);
            query.addCriteria(criteria);
        }
        else if (isGrouping == "Yes" && isTrending == "No") {
            criteria = Criteria.where(projectMetric.getGroupBy()).in(distinctValue);
            query.addCriteria(criteria);
        }

        Long valKey = 0l;
        if(isProjectsEmpty == "No")
            valKey = mongoOperation.count(query, collectionClass);
        System.out.println("CountAnd value * "+valKey);
        return valKey;
    }

    public long sum(String className, Set<Map.Entry<String, String>> valueSet, ProjectMetric projectMetric, String isTrending, String isGrouping, Date startDate, Date endDate, String distinctValue)throws Exception {

        Class collectionClass = Class.forName("com.cts.idashboard.services.metricservice.data." + className);

        Long valKey = null;
        String fieldName = null;
        Criteria criteria = null;
        List<HashMap> res = null;

         for (Map.Entry<String, String> val : valueSet) {
            System.out.println("Value map -- *** -- " + String.valueOf(val.getValue()));
            if (val.getKey().equals("collection"))
                collectionClass = Class.forName("com.cts.idashboard.services.metricservice.data." + String.valueOf(val.getValue()));
            else if(val.getKey().equals("sum_field"))
                fieldName = val.getValue();
        }

        // Applying project filter criteria
        if(criteria == null)
            criteria = projectFilter(collectionClass, projectMetric);
        else
            criteria.andOperator(projectFilter(collectionClass, projectMetric));

        // Applying trendBy or GroupBy criteria
        if (isGrouping == "No" && isTrending == "Yes") {
            if (criteria == null)
                criteria = Criteria.where(projectMetric.getTrendBy()).gte(startDate).lte(endDate);
            else
                criteria.and(projectMetric.getTrendBy()).gte(startDate).lte(endDate);
        }
        else if (isGrouping == "Yes" && isTrending == "No") {
            if (criteria == null)
                criteria = Criteria.where(projectMetric.getGroupBy()).in(distinctValue);
            else
                criteria.and(projectMetric.getGroupBy()).in(distinctValue);
        }

        if (criteria == null) {
            System.out.println("Criteria is null");
            res = mongoOperation.aggregate(newAggregation(
                            collectionClass,
                            group().sum(fieldName).as("Sum_value")),
                    HashMap.class).getMappedResults();
        } else {
            System.out.println("Criteria is not null");
            res = mongoOperation.aggregate(newAggregation(
                            collectionClass,
                            match(criteria),
                            group().sum(fieldName).as("Sum_value")),
                    HashMap.class).getMappedResults();
        }

        if (res.size() > 0)
            valKey = Long.valueOf(res.get(0).get("Sum_value").toString());
        else
            valKey = Long.valueOf(0);

        System.out.println("Sum value ** "+valKey);
        return valKey;
    }

    public long sumAnd(String className, Set<Map.Entry<String, String>> valueSet, ProjectMetric projectMetric, String isTrending, String isGrouping, Date startDate, Date endDate, String distinctValue) throws Exception {

        Class collectionClass = Class.forName("com.cts.idashboard.services.metricservice.data." + className);

        Long valKey = null;
        String fieldName = null;
        Criteria criteria = null;
        List<HashMap> res = null;

        for (Map.Entry<String, String> val : valueSet) {
            System.out.println("Value map -- *** -- " + String.valueOf(val.getValue()));

            if (val.getKey().equals("collection")) {
                collectionClass = Class.forName("com.cts.idashboard.services.metricservice.data." + String.valueOf(val.getValue()));
            }
            else if (val.getKey().equals("sum_field")) {
                fieldName = val.getValue();
            }
            else {
                if (criteria == null)
                    criteria = Criteria.where(val.getKey()).is(val.getValue());
                else
                    criteria.and(val.getKey()).is(val.getValue());
            }
        }


        // Applying project filter criteria
        if(criteria == null)
            criteria = projectFilter(collectionClass, projectMetric);
        else
            criteria.andOperator(projectFilter(collectionClass, projectMetric));

        // Applying trendBy or GroupBy criteria
        if (isGrouping == "No" && isTrending == "Yes") {
            if (criteria == null)
                criteria = Criteria.where(projectMetric.getTrendBy()).gte(startDate).lte(endDate);
            else
                criteria.and(projectMetric.getTrendBy()).gte(startDate).lte(endDate);
        }
        else if (isGrouping == "Yes" && isTrending == "No") {
            if (criteria == null)
                criteria = Criteria.where(projectMetric.getGroupBy()).in(distinctValue);
            else
                criteria.and(projectMetric.getGroupBy()).in(distinctValue);
        }

        if (criteria == null) {
            res = mongoOperation.aggregate(newAggregation(
                            collectionClass,
                            group().sum(fieldName).as("Sum_And_value")),
                    HashMap.class).getMappedResults();
        } else {
            res = mongoOperation.aggregate(newAggregation(
                            collectionClass,
                            match(criteria),
                            group().sum(fieldName).as("Sum_And_value")),
                    HashMap.class).getMappedResults();
        }

        if (res.size() > 0)
            valKey = Long.valueOf(res.get(0).get("Sum_And_value").toString());
        else
            valKey = Long.valueOf(0);

        System.out.println("SumAnd value ** "+valKey);
        return valKey;
    }

    public double avg(String className, Set<Map.Entry<String, String>> valueSet, ProjectMetric projectMetric, String isTrending, String isGrouping, Date startDate, Date endDate, String distinctValue) throws Exception {

        Class collectionClass = Class.forName("com.cts.idashboard.services.metricservice.data." + className);

        Double valKey = null;
        String fieldName = null;
        Criteria criteria = null;
        List<HashMap> res = null;

        for (Map.Entry<String, String> val : valueSet) {
            System.out.println("Value map -- *** -- " + String.valueOf(val.getValue()));
            if (val.getKey().equals("collection"))
                collectionClass = Class.forName("com.cts.idashboard.services.metricservice.data." + String.valueOf(val.getValue()));
            else if(val.getKey().equals("avg_field"))
                fieldName = val.getValue();
        }

        // Applying project filter criteria
        if(criteria == null)
            criteria = projectFilter(collectionClass, projectMetric);
        else
            criteria.andOperator(projectFilter(collectionClass, projectMetric));

        // Applying trendBy or GroupBy criteria
        if (isGrouping == "No" && isTrending == "Yes") {
            if (criteria == null)
                criteria = Criteria.where(projectMetric.getTrendBy()).gte(startDate).lte(endDate);
            else
                criteria.and(projectMetric.getTrendBy()).gte(startDate).lte(endDate);
        }
        else if (isGrouping == "Yes" && isTrending == "No") {
            if (criteria == null)
                criteria = Criteria.where(projectMetric.getGroupBy()).in(distinctValue);
            else
                criteria.and(projectMetric.getGroupBy()).in(distinctValue);
        }

        if (criteria == null) {
            res = mongoOperation.aggregate(newAggregation(
                            collectionClass,
                            group().avg(fieldName).as("Avg_value")),
                    HashMap.class).getMappedResults();
        } else {
            res = mongoOperation.aggregate(newAggregation(
                            collectionClass,
                            match(criteria),
                            group().avg(fieldName).as("Avg_value")),
                    HashMap.class).getMappedResults();
        }

        if (res.size() > 0)
            valKey = Double.valueOf(res.get(0).get("Avg_value").toString());
        else
            valKey = Double.valueOf(0);

        System.out.println("Avg value ** "+valKey);
        return valKey;
    }

    public double avgAnd(String className, Set<Map.Entry<String, String>> valueSet, ProjectMetric projectMetric, String isTrending, String isGrouping, Date startDate, Date endDate, String distinctValue) throws Exception {

        Class collectionClass = Class.forName("com.cts.idashboard.services.metricservice.data." + className);

        Double valKey = null;
        String fieldName = null;
        Criteria criteria = null;
        List<HashMap> res = null;

        for (Map.Entry<String, String> val : valueSet) {
            System.out.println("Value map -- *** -- " + String.valueOf(val.getValue()));

            if (val.getKey().equals("collection")){
                collectionClass = Class.forName("com.cts.idashboard.services.metricservice.data." + String.valueOf(val.getValue()));
            }
            else if (val.getKey().equals("avg_field")) {
                fieldName = val.getValue();
            }
            else {
                if (criteria == null)
                    criteria = Criteria.where(val.getKey()).is(val.getValue());
                else
                    criteria.and(val.getKey()).is(val.getValue());
            }
        }

        // Applying project filter criteria
        if(criteria == null)
            criteria = projectFilter(collectionClass, projectMetric);
        else
            criteria.andOperator(projectFilter(collectionClass, projectMetric));

        // Applying trendBy or GroupBy criteria
        if (isGrouping == "No" && isTrending == "Yes") {
            if (criteria == null)
                criteria = Criteria.where(projectMetric.getTrendBy()).gte(startDate).lte(endDate);
            else
                criteria.and(projectMetric.getTrendBy()).gte(startDate).lte(endDate);
        }
        else if (isGrouping == "Yes" && isTrending == "No") {
            if (criteria == null)
                criteria = Criteria.where(projectMetric.getGroupBy()).in(distinctValue);
            else
                criteria.and(projectMetric.getGroupBy()).in(distinctValue);
        }

        if (criteria == null) {
            res = mongoOperation.aggregate(newAggregation(
                            collectionClass,
                            group().avg(fieldName).as("Avg_And_value")),
                    HashMap.class).getMappedResults();
        } else {
            res = mongoOperation.aggregate(newAggregation(
                            collectionClass,
                            match(criteria),
                            group().avg(fieldName).as("Avg_And_value")),
                    HashMap.class).getMappedResults();
        }

        if (res.size() > 0)
            valKey = Double.valueOf(res.get(0).get("Avg_And_value").toString());
        else
            valKey = Double.valueOf(0);

        System.out.println("AvgAnd value ** "+valKey);
        return valKey;
    }


    public double sumIS0(String className, Set<Map.Entry<String, String>> valueSet, ProjectMetric projectMetric, String isTrending, String isGrouping, Date startDate, Date endDate, String distinctValue) throws Exception {

        Class collectionClass = Class.forName("com.cts.idashboard.services.metricservice.data." + className);

        Long totalValue = null;
        String fieldName = null;
        Criteria criteria = null;
        List<HashMap> res = null;

        for (Map.Entry<String, String> val : valueSet) {
            System.out.println("Value map -- *** -- " + String.valueOf(val.getValue()));
            if (val.getKey().equals("collection"))
                collectionClass = Class.forName("com.cts.idashboard.services.metricservice.data." + String.valueOf(val.getValue()));
            else if(val.getKey().equals("sum_field"))
                fieldName = val.getValue();
        }

        // Applying project filter criteria
        if(criteria == null)
            criteria = projectFilter(collectionClass, projectMetric);
        else
            criteria.andOperator(projectFilter(collectionClass, projectMetric));

        // Applying trendBy or GroupBy criteria
        if (isGrouping == "No" && isTrending == "Yes") {
            if (criteria == null)
                criteria = Criteria.where(projectMetric.getTrendBy()).gte(startDate).lte(endDate);
            else
                criteria.and(projectMetric.getTrendBy()).gte(startDate).lte(endDate);
        }
        else if (isGrouping == "Yes" && isTrending == "No") {
            if (criteria == null)
                criteria = Criteria.where(projectMetric.getGroupBy()).in(distinctValue);
            else
                criteria.and(projectMetric.getGroupBy()).in(distinctValue);
        }

        if (criteria == null) {
            res = mongoOperation.aggregate(newAggregation(
                            collectionClass,
                            group().sum(fieldName).as("Sum_ISO_value")),
                    HashMap.class).getMappedResults();
        } else {
            res = mongoOperation.aggregate(newAggregation(
                            collectionClass,
                            match(criteria),
                            group().sum(fieldName).as("Sum_ISO_value")),
                    HashMap.class).getMappedResults();
        }

        if (res.size() > 0)
            totalValue = Long.valueOf(res.get(0).get("Sum_ISO_value").toString());
        else
            totalValue = Long.valueOf(0);

        /*
        long hours = totalValue / 3600;
        long minutes = (totalValue % 3600) / 60;
        long seconds = totalValue % 60;
        long milliSeconds = (totalValue*1000) % 1000;

        String timeString = String.format("%02d:%02d:%02d:%03d", hours, minutes, seconds, milliSeconds);
        System.out.println("Sum IS0 value - " + timeString);
        */
        System.out.println("SumISO value in hours ** " + Double.valueOf(totalValue / (3600)));
        return Double.valueOf(totalValue / (3600));
    }

    public double sumIS0And(String className, Set<Map.Entry<String, String>> valueSet, ProjectMetric projectMetric, String isTrending, String isGrouping, Date startDate, Date endDate, String distinctValue) throws Exception {

        Class collectionClass = Class.forName("com.cts.idashboard.services.metricservice.data." + className);

        Long totalValue = null;
        String fieldName = null;
        Criteria criteria = null;
        List<HashMap> res = null;

        for (Map.Entry<String, String> val : valueSet) {
            System.out.println("Value map -- *** -- " + String.valueOf(val.getValue()));
            if (val.getKey().equals("collection")) {
                collectionClass = Class.forName("com.cts.idashboard.services.metricservice.data." + String.valueOf(val.getValue()));
            }
            else if (val.getKey().equals("sum_field")) {
                fieldName = val.getValue();
            }
            else {
                if (criteria == null)
                    criteria = Criteria.where(val.getKey()).is(val.getValue());
                else
                    criteria.and(val.getKey()).is(val.getValue());
            }
        }

        // Applying project filter criteria
        if(criteria == null)
            criteria = projectFilter(collectionClass, projectMetric);
        else
            criteria.andOperator(projectFilter(collectionClass, projectMetric));

        // Applying trendBy or GroupBy criteria
        if (isGrouping == "No" && isTrending == "Yes") {
            if (criteria == null)
                criteria = Criteria.where(projectMetric.getTrendBy()).gte(startDate).lte(endDate);
            else
                criteria.and(projectMetric.getTrendBy()).gte(startDate).lte(endDate);
        }
        else if (isGrouping == "Yes" && isTrending == "No") {
            if (criteria == null)
                criteria = Criteria.where(projectMetric.getGroupBy()).in(distinctValue);
            else
                criteria.and(projectMetric.getGroupBy()).in(distinctValue);
        }

        if (criteria == null) {
            res = mongoOperation.aggregate(newAggregation(
                            collectionClass,
                            group().sum(fieldName).as("Sum_ISO_And_value")),
                    HashMap.class).getMappedResults();
        }
        else {
            res = mongoOperation.aggregate(newAggregation(
                            collectionClass,
                            match(criteria),
                            group().sum(fieldName).as("Sum_ISO_And_value")),
                    HashMap.class).getMappedResults();
        }

        if (res.size() > 0)
            totalValue = Long.valueOf(res.get(0).get("Sum_ISO_And_value").toString());
        else
            totalValue = Long.valueOf(0);

        /*
        long hours = totalValue / 3600;
        long minutes = (totalValue % 3600) / 60;
        long seconds = totalValue % 60;
        long milliSeconds = (totalValue*1000) % 1000;

        String timeString = String.format("%02d:%02d:%02d:%03d", hours, minutes, seconds, milliSeconds);
        System.out.println("SumIS0And value - " + timeString);
        */

        System.out.println("SumISOAnd value in hours:" + Double.valueOf(totalValue / 3600));
        return Double.valueOf(totalValue / 3600);
    }

    public double sumIS0Diff(String className, Set<Map.Entry<String, String>> valueSet, ProjectMetric projectMetric, String isTrending, String isGrouping, Date startDate, Date endDate, String distinctValue) throws Exception {

        Class collectionClass = Class.forName("com.cts.idashboard.services.metricservice.data." + className);

        Long totalValue = null;
        String field1 = null;
        String field2 = null;
        Criteria criteria = null;
        List<HashMap> res = null;

        for (Map.Entry<String, String> val : valueSet) {
            System.out.println("Value map -- *** -- " + String.valueOf(val.getValue()));
            if (val.getKey().equals("collection"))
                collectionClass = Class.forName("com.cts.idashboard.services.metricservice.data." + String.valueOf(val.getValue()));
            else if (val.getKey().equals("start"))
                field1 = val.getValue();
            else if (val.getKey().equals("end"))
                field2 = val.getValue();
        }

        // Applying project filter criteria
        if(criteria == null)
            criteria = projectFilter(collectionClass, projectMetric);
        else
            criteria.andOperator(projectFilter(collectionClass, projectMetric));

        // Applying trendBy or GroupBy criteria
        if (isGrouping == "No" && isTrending == "Yes") {
            if (criteria == null)
                criteria = Criteria.where(projectMetric.getTrendBy()).gte(startDate).lte(endDate);
            else
                criteria.and(projectMetric.getTrendBy()).gte(startDate).lte(endDate);
        }
        else if (isGrouping == "Yes" && isTrending == "No") {
            if (criteria == null)
                criteria = Criteria.where(projectMetric.getGroupBy()).in(distinctValue);
            else
                criteria.and(projectMetric.getGroupBy()).in(distinctValue);
        }

        if (criteria == null) {
            res = mongoOperation.aggregate(newAggregation(
                            collectionClass,
                            project("id").andExpression(field2 + "-" + field1).as("diff"),
                            group().sum("diff").as("sum_ISO_Diff_value")),
                    HashMap.class).getMappedResults();
        }
        else {
            res = mongoOperation.aggregate(newAggregation(
                            collectionClass,
                            match(criteria),
                            project("id").andExpression(field2 + "-" + field1).as("diff"),
                            group().sum("diff").as("sum_ISO_Diff_value")),
                    HashMap.class).getMappedResults();
        }

        if (res.size() > 0)
            totalValue = Long.valueOf(res.get(0).get("sum_ISO_Diff_value").toString());
        else
            totalValue = Long.valueOf(0);

        /*
        long totalSecs = totalValue/1000;
        long hours = totalSecs / 3600;
        long minutes = (totalSecs % 3600) / 60;
        long seconds = totalSecs % 60;
        long milliSeconds = totalValue % 1000;
        System.out.println("Sum ISO Diff value - Total milli seconds :"+totalValue);
        String timeString = String.format("%02d:%02d:%02d:%03d", hours, minutes, seconds, milliSeconds);
        System.out.println("Sum ISO Diff value - ISO Time format - " + timeString);

        */
        System.out.println("SumISODiff value in hours ** :" + Double.valueOf(totalValue / (1000 * 3600)));
        return Double.valueOf(totalValue / (1000 * 3600));
    }


    public double sumIS0DiffAnd(String className, Set<Map.Entry<String, String>> valueSet, ProjectMetric projectMetric, String isTrending, String isGrouping, Date startDate, Date endDate, String distinctValue) throws Exception {

        Class collectionClass = Class.forName("com.cts.idashboard.services.metricservice.data." + className);

        Long totalValue = null;
        String field1 = null;
        String field2 = null;
        Criteria criteria = null;
        List<HashMap> res = null;

        for (Map.Entry<String, String> val : valueSet) {
            System.out.println("Value map -- *** -- " + String.valueOf(val.getValue()));

            if (val.getKey().equals("collection"))
                collectionClass = Class.forName("com.cts.idashboard.services.metricservice.data." + String.valueOf(val.getValue()));
            else if (val.getKey().equals("start"))
                field1 = val.getValue();
            else if (val.getKey().equals("end"))
                field2 = val.getValue();
            else {
                if (criteria == null)
                    criteria = Criteria.where(val.getKey()).is(val.getValue());
                else
                    criteria.and(val.getKey()).is(val.getValue());
            }
        }

        // Applying project filter criteria
        if(criteria == null)
            criteria = projectFilter(collectionClass, projectMetric);
        else
            criteria.andOperator(projectFilter(collectionClass, projectMetric));

        // Applying trendBy or GroupBy criteria
        if (isGrouping == "No" && isTrending == "Yes") {
            if (criteria == null)
                criteria = Criteria.where(projectMetric.getTrendBy()).gte(startDate).lte(endDate);
            else
                criteria.and(projectMetric.getTrendBy()).gte(startDate).lte(endDate);
        }
        else if (isGrouping == "Yes" && isTrending == "No") {
            if (criteria == null)
                criteria = Criteria.where(projectMetric.getGroupBy()).in(distinctValue);
            else
                criteria.and(projectMetric.getGroupBy()).in(distinctValue);
        }

        if (criteria == null) {
            res = mongoOperation.aggregate(newAggregation(
                            collectionClass,
                            project("id").andExpression(field2 + "-" + field1).as("diff"),
                            group().sum("diff").as("sum_ISO_Diff_And_value")),
                    HashMap.class).getMappedResults();
        } else {
            res = mongoOperation.aggregate(newAggregation(
                            collectionClass,
                            match(criteria),
                            project("id").andExpression(field2 + "-" + field1).as("diff"),
                            group().sum("diff").as("sum_ISO_Diff_And_value")),
                    HashMap.class).getMappedResults();
        }

        if (res.size() > 0)
            totalValue = Long.valueOf(res.get(0).get("sum_ISO_Diff_And_value").toString());
        else
            totalValue = Long.valueOf(0);

        System.out.println("SumISODiffAnd value in hours ** " + Double.valueOf(totalValue / (1000 * 3600)));
        /*
        long totalSecs = totalValue/1000;
        long hours = totalSecs / 3600;
        long minutes = (totalSecs % 3600) / 60;
        long seconds = totalSecs % 60;
        long milliSeconds = totalValue % 1000;

        System.out.println("Sum ISO Diff value - Total milli seconds :"+totalValue);
        String timeString = String.format("%02d:%02d:%02d:%03d", hours, minutes, seconds, milliSeconds);
        System.out.println("Sum ISO Diff value - ISO Time format - " + timeString);
        */
        return Double.valueOf(totalValue / (1000 * 3600));
    }

    public long max(String className, Set<Map.Entry<String, String>> valueSet, ProjectMetric projectMetric, String isTrending, String isGrouping, Date startDate, Date endDate, String distinctValue) throws Exception {

        Class collectionClass = Class.forName("com.cts.idashboard.services.metricservice.data." + className);

        Long valKey = null;
        String fieldName = null;
        Criteria criteria = null;
        List<HashMap> res = null;

        for (Map.Entry<String, String> val : valueSet) {
            System.out.println("Value map -- *** -- " + String.valueOf(val.getValue()));

            if (val.getKey().equals("collection"))
                collectionClass = Class.forName("com.cts.idashboard.services.metricservice.data." + String.valueOf(val.getValue()));
            else if (val.getKey().equals("max_field"))
                fieldName = val.getValue();
        }

        // Applying project filter criteria
        if(criteria == null)
            criteria = projectFilter(collectionClass, projectMetric);
        else
            criteria.andOperator(projectFilter(collectionClass, projectMetric));

        // Applying trendBy or GroupBy criteria
        if (isGrouping.equals("No") && isTrending.equals("Yes")) {
            if (criteria == null)
                criteria = Criteria.where(projectMetric.getTrendBy()).gte(startDate).lte(endDate);
            else
                criteria.and(projectMetric.getTrendBy()).gte(startDate).lte(endDate);
        }
        else if (isGrouping.equals("Yes") && isTrending.equals("No")) {
            if (criteria == null)
                criteria = Criteria.where(projectMetric.getGroupBy()).in(distinctValue);
            else
                criteria.and(projectMetric.getGroupBy()).in(distinctValue);
        }

        if (criteria == null) {
            res = mongoOperation.aggregate(newAggregation(
                            collectionClass,
                            group().max(fieldName).as("Max_value")),
                    HashMap.class).getMappedResults();
        }
        else {
            res = mongoOperation.aggregate(newAggregation(
                            collectionClass,
                            match(criteria),
                            group().max(fieldName).as("Max_value")),
                    HashMap.class).getMappedResults();
        }

        if (res.size() > 0)
            valKey = Long.valueOf(res.get(0).get("Max_value").toString());
        else
            valKey = Long.valueOf(0);

        System.out.println("Max value ** "+valKey);
        return valKey;
    }

    public long maxAnd(String className, Set<Map.Entry<String, String>> valueSet, ProjectMetric projectMetric, String isTrending, String isGrouping, Date startDate, Date endDate, String distinctValue) throws Exception {

        Class collectionClass = Class.forName("com.cts.idashboard.services.metricservice.data." + className);

        Long valKey = null;
        String fieldName = null;
        Criteria criteria = null;
        List<HashMap> res = null;

        for (Map.Entry<String, String> val : valueSet) {
            System.out.println("Value map -- *** -- " + String.valueOf(val.getValue()));
            if (val.getKey().equals("collection"))
                collectionClass = Class.forName("com.cts.idashboard.services.metricservice.data." + String.valueOf(val.getValue()));
            else if (val.getKey().equals("max_field")) {
                fieldName = val.getValue();
            }
            else {
                if (criteria == null)
                    criteria = Criteria.where(val.getKey()).is(val.getValue());
                else
                    criteria.and(val.getKey()).is(val.getValue());
            }
        }

        // Applying project filter criteria
        if(criteria == null)
            criteria = projectFilter(collectionClass, projectMetric);
        else
            criteria.andOperator(projectFilter(collectionClass, projectMetric));

        // Applying trendBy or GroupBy criteria
        if (isGrouping.equals("No") && isTrending.equals("Yes")) {
            if (criteria == null)
                criteria = Criteria.where(projectMetric.getTrendBy()).gte(startDate).lte(endDate);
            else
                criteria.and(projectMetric.getTrendBy()).gte(startDate).lte(endDate);
        }
        else if (isGrouping.equals("Yes") && isTrending.equals("No")) {
            if (criteria == null)
                criteria = Criteria.where(projectMetric.getGroupBy()).in(distinctValue);
            else
                criteria.and(projectMetric.getGroupBy()).in(distinctValue);
        }

        if (criteria == null) {
            res = mongoOperation.aggregate(newAggregation(
                            collectionClass,
                            group().max(fieldName).as("Max_And_value")),
                    HashMap.class).getMappedResults();
        }
        else {
            res = mongoOperation.aggregate(newAggregation(
                            collectionClass,
                            match(criteria),
                            group().max(fieldName).as("Max_And_value")),
                    HashMap.class).getMappedResults();
        }

        if (res.size() > 0)
            valKey = Long.valueOf(res.get(0).get("Max_And_value").toString());
        else
            valKey = Long.valueOf(0);

        System.out.println("MaxAnd value ** "+valKey);
        return valKey;
    }


    public long min(String className, Set<Map.Entry<String, String>> valueSet, ProjectMetric projectMetric, String isTrending, String isGrouping, Date startDate, Date endDate, String distinctValue) throws Exception {

        Class collectionClass = Class.forName("com.cts.idashboard.services.metricservice.data." + className);

        Long valKey = null;
        String fieldName = null;
        Criteria criteria = null;
        List<HashMap> res = null;

        for (Map.Entry<String, String> val : valueSet) {
            System.out.println("Value map -- *** -- " + String.valueOf(val.getValue()));

            if (val.getKey().equals("collection"))
                collectionClass = Class.forName("com.cts.idashboard.services.metricservice.data." + String.valueOf(val.getValue()));
            else if (val.getKey().equals("min_field"))
                fieldName = val.getValue();
        }

        // Applying project filter criteria
        if(criteria == null)
            criteria = projectFilter(collectionClass, projectMetric);
        else
            criteria.andOperator(projectFilter(collectionClass, projectMetric));

        // Applying trendBy or GroupBy criteria
        if (isGrouping.equals("No") && isTrending.equals("Yes")) {
            if (criteria == null)
                criteria = Criteria.where(projectMetric.getTrendBy()).gte(startDate).lte(endDate);
            else
                criteria.and(projectMetric.getTrendBy()).gte(startDate).lte(endDate);
        }
        else if (isGrouping.equals("Yes") && isTrending.equals("No")) {
            if (criteria == null)
                criteria = Criteria.where(projectMetric.getGroupBy()).in(distinctValue);
            else
                criteria.and(projectMetric.getGroupBy()).in(distinctValue);
        }

        if (criteria == null) {
            res = mongoOperation.aggregate(newAggregation(
                            collectionClass,
                            group().min(fieldName).as("Min_value")),
                    HashMap.class).getMappedResults();
        } else {
            res = mongoOperation.aggregate(newAggregation(
                            collectionClass,
                            match(criteria),
                            group().min(fieldName).as("Min_value")),
                    HashMap.class).getMappedResults();
        }

        if (res.size() > 0)
            valKey = Long.valueOf(res.get(0).get("Min_value").toString());
        else
            valKey = Long.valueOf(0);

        System.out.println("Min value ** "+valKey);
        return valKey;
    }

    public long minAnd(String className, Set<Map.Entry<String, String>> valueSet, ProjectMetric projectMetric, String isTrending, String isGrouping, Date startDate, Date endDate, String distinctValue) throws Exception {

        Class collectionClass = Class.forName("com.cts.idashboard.services.metricservice.data." + className);

        Long valKey = null;
        String fieldName = null;
        Criteria criteria = null;
        List<HashMap> res = null;

        for (Map.Entry<String, String> val : valueSet) {
            System.out.println("Value map -- *** -- " + String.valueOf(val.getValue()));
            if (val.getKey().equals("collection"))
                collectionClass = Class.forName("com.cts.idashboard.services.metricservice.data." + String.valueOf(val.getValue()));
            else if (val.getKey().equals("min_field")) {
                fieldName = val.getValue();
            }
            else {
                if (criteria == null)
                    criteria = Criteria.where(val.getKey()).is(val.getValue());
                else
                    criteria.and(val.getKey()).is(val.getValue());
            }
        }

        // Applying project filter criteria
        if(criteria == null)
            criteria = projectFilter(collectionClass, projectMetric);
        else
            criteria.andOperator(projectFilter(collectionClass, projectMetric));

        // Applying trendBy or GroupBy criteria
        if (isGrouping.equals("No") && isTrending.equals("Yes")) {
            if (criteria == null)
                criteria = Criteria.where(projectMetric.getTrendBy()).gte(startDate).lte(endDate);
            else
                criteria.and(projectMetric.getTrendBy()).gte(startDate).lte(endDate);
        } else if (isGrouping.equals("Yes") && isTrending.equals("No")) {
            if (criteria == null)
                criteria = Criteria.where(projectMetric.getGroupBy()).in(distinctValue);
            else
                criteria.and(projectMetric.getGroupBy()).in(distinctValue);
        }

        if (criteria == null) {
            res = mongoOperation.aggregate(newAggregation(
                            collectionClass,
                            group().min(fieldName).as("Min_And_value")),
                    HashMap.class).getMappedResults();
        }
        else {
            res = mongoOperation.aggregate(newAggregation(
                            collectionClass,
                            match(criteria),
                            group().min(fieldName).as("Min_And_value")),
                    HashMap.class).getMappedResults();
        }

        if (res.size() > 0)
            valKey = Long.valueOf(res.get(0).get("Min_And_value").toString());
        else
            valKey = Long.valueOf(0);

        System.out.println("MinAnd value ** "+valKey);
        return valKey;
    }

    public Criteria projectFilter(Class collectionClass, ProjectMetric projectMetric) {

        Criteria criteria = null;

        if (collectionClass.toString().toLowerCase().contains("jira")) {
            System.out.println("Jira Project Names : "+projectMetric.getJiraProjects());
            if (projectMetric.getJiraProjects() != null) {
                criteria = Criteria.where("projectName").in(projectMetric.getJiraProjects());
            }
        }
        else if (collectionClass.toString().toLowerCase().contains("alm")) {
            System.out.println("ALM Project Names : " + projectMetric.getAlmProjects());
            if (projectMetric.getAlmProjects() != null) {
                criteria = Criteria.where("projectName").in(projectMetric.getAlmProjects());
            }
        }

        else if (collectionClass.toString().toLowerCase().contains("rally")) {
            System.out.println("Rally Project Names : " + projectMetric.getRallyProjects());
            if (projectMetric.getRallyProjects() != null) {
                criteria = Criteria.where("projectName").in(projectMetric.getRallyProjects());
            }
        }

        else if (collectionClass.toString().toLowerCase().contains("zephyr")) {
            if (collectionClass.toString().toLowerCase().contains("zephyrscale")) {
                System.out.println("Zephyr scale Project Names : " + projectMetric.getZephyrScaleProjects());
                if (projectMetric.getZephyrScaleProjects() != null){
                    criteria = Criteria.where("projectName").in(projectMetric.getZephyrScaleProjects());
                }
            }
            else {
                System.out.println("zephyr Project Names : " + projectMetric.getZephyrProjects());
                if (projectMetric.getZephyrProjects() != null){
                    criteria = Criteria.where("projectName").in(projectMetric.getZephyrProjects());
                }
            }
        }

        else if (collectionClass.toString().toLowerCase().contains("servicenow")) {
            System.out.println("Service now Project Names : " + projectMetric.getServiceNowIncidentProjects());
            if (projectMetric.getServiceNowIncidentProjects() != null) {
                criteria = Criteria.where("projectName").in(projectMetric.getServiceNowIncidentProjects());
            }
        }

        else if (collectionClass.toString().toLowerCase().contains("bots")) {
            System.out.println("Bot Project Names : " + projectMetric.getBotsDefectsProjects());
            if (projectMetric.getBotsDefectsProjects() != null) {
                criteria = Criteria.where("projectName").in(projectMetric.getBotsDefectsProjects());
            }
        }

        else if (collectionClass.toString().toLowerCase().contains("xray")) {
            System.out.println(" XRayProject Names : " + projectMetric.getXrayProjects());
            if (projectMetric.getXrayProjects() != null) {
                criteria = Criteria.where("projectName").in(projectMetric.getXrayProjects());
            }
        }

        else if (collectionClass.toString().toLowerCase().contains("git")) {
            System.out.println(" Git Project Names : " + projectMetric.getGitProjects());
            if (projectMetric.getGitProjects() != null) {
                criteria = Criteria.where("name").in(projectMetric.getGitProjects());
            }
        }

        else if (collectionClass.toString().toLowerCase().contains("jenkins")) {
            System.out.println("Jenkins Project Names : " + projectMetric.getJenkinsProjects());
            if (projectMetric.getJenkinsProjects() != null) {
                criteria = Criteria.where("projectName").in(projectMetric.getJenkinsProjects());
            }
        }

        return criteria;
    }
}
