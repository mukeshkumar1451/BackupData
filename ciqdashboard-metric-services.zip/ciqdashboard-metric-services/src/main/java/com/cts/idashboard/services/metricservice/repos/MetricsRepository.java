package com.cts.idashboard.services.metricservice.repos;

import com.cts.idashboard.services.metricservice.data.MetricResults;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;
import java.util.Optional;


public interface MetricsRepository extends MongoRepository<MetricResults, String> {

    Optional<MetricResults> findByMetricNameAndDashboardNameAndItemId(String metricName, String dashboardName, String itemId);

    Optional<MetricResults> findByMetricNameAndItemId(String metricName, String itemId);

    List<MetricResults> findByProjectNameAndDashboardNameAndPageName(String projectName, String dashboardName, String pageName);


}
