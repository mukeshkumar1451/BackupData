package com.cts.idashboard.services.metricservice.services;


import com.cts.idashboard.services.metricservice.data.JiraIssue;
import com.cts.idashboard.services.metricservice.data.ProjectMetric;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Component;

import java.lang.reflect.Array;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

@Component
public class CustomFunctions {

    @Autowired
    MongoOperations mongoOperation;

    public ProjectMetric executeCustomFunction(ProjectMetric projectMetric) throws Exception {

        System.out.println("Custom function name : "+projectMetric.getCustomFunctionName());
        if(projectMetric.getCustomFunctionName().equalsIgnoreCase("defect_ageing")){
            projectMetric = defectAgeing(projectMetric);
        }
        else if(projectMetric.getCustomFunctionName().equalsIgnoreCase("defect_ageing_stack")){
            projectMetric = defectAgeingStack(projectMetric);
        }
        else if(projectMetric.getCustomFunctionName().equalsIgnoreCase("defect_ageing_agile")){
            projectMetric = defectAgeingLesserDuration(projectMetric);
        }
        else if(projectMetric.getCustomFunctionName().equalsIgnoreCase("execution_progress")){
            projectMetric = executionProgress(projectMetric);
        }
        else if(projectMetric.getCustomFunctionName().equalsIgnoreCase("quality_metrics")){
            projectMetric = qualityMetrics(projectMetric);
        }
        System.out.println();
        return projectMetric;
    }

    public ProjectMetric executionProgress(ProjectMetric projectMetric) throws ClassNotFoundException {

        String className = "JiraIssue";
        Class collectionClass = Class.forName("com.cts.idashboard.services.metricservice.data." + className);
        JSONArray metricValues = new JSONArray();

        List<String> projects = mongoOperation.findDistinct("projectName", JiraIssue.class, String.class);
        for(String project: projects) {
            System.out.println("*** PROJECT : "+project+" ***");

            List<String> distinctPriorityValues = mongoOperation.findDistinct("priority", JiraIssue.class, String.class);

            System.out.println("Priority wise distinct data * "+distinctPriorityValues);

            JSONArray series =new JSONArray();

            for(String priority : distinctPriorityValues){

                Query query = new Query();
                Criteria criteria = null;

                // Applying defect ageing filter
                criteria = Criteria.where("statusCategoryName").ne("Done");
                if(criteria !=null){
                    query.addCriteria(criteria);
                }

                // Applying priority filter
                criteria = Criteria.where("priority").is(priority);
                if(criteria !=null){
                    query.addCriteria(criteria);
                }

                JSONObject evaluatedResult1 = new JSONObject();
                int value = 0;
                JSONObject evaluatedResult = new JSONObject();
                value = (int) Math.random();
                System.out.println();

                evaluatedResult1.put("name", priority);
                evaluatedResult1.put("value", value);
                evaluatedResult1.put("label", priority);
                evaluatedResult1.put("link", null);
                evaluatedResult1.put("children", null);
                evaluatedResult1.put("series", null);

                series.add(evaluatedResult1);
            }

            JSONObject evaluatedResult = new JSONObject();
            evaluatedResult.put("name", project);
            evaluatedResult.put("value", 0);
            evaluatedResult.put("label", project);
            evaluatedResult.put("link", null);
            evaluatedResult.put("children", null);
            evaluatedResult.put("series", series);

            // add evaluated values
            metricValues.add(evaluatedResult);
        }
        projectMetric.setMetricValues(metricValues);


        return projectMetric;
    }

    public ProjectMetric qualityMetrics(ProjectMetric projectMetric) throws ClassNotFoundException {

        String className = "JiraIssue";
        Class collectionClass = Class.forName("com.cts.idashboard.services.metricservice.data." + className);
        JSONArray metricValues = new JSONArray();

        List<String> projects = mongoOperation.findDistinct("projectName", JiraIssue.class, String.class);
        for(String project: projects) {
            System.out.println("*** PROJECT : "+project+" ***");

            List<String> distinctPriorityValues = mongoOperation.findDistinct("priority", JiraIssue.class, String.class);

            System.out.println("Priority wise distinct data * "+distinctPriorityValues);

            JSONArray series =new JSONArray();

            for(String priority : distinctPriorityValues){

                Query query = new Query();
                Criteria criteria = null;

                // Applying defect ageing filter
                criteria = Criteria.where("statusCategoryName").ne("Done");
                if(criteria !=null){
                    query.addCriteria(criteria);
                }

                // Applying priority filter
                criteria = Criteria.where("priority").is(priority);
                if(criteria !=null){
                    query.addCriteria(criteria);
                }

                JSONObject evaluatedResult1 = new JSONObject();
                int value = 0;
                JSONObject evaluatedResult = new JSONObject();
                value = (int) Math.random();
                System.out.println();

                evaluatedResult1.put("name", priority);
                evaluatedResult1.put("value", value);
                evaluatedResult1.put("label", priority);
                evaluatedResult1.put("link", null);
                evaluatedResult1.put("children", null);
                evaluatedResult1.put("series", null);

                series.add(evaluatedResult1);
            }

            JSONObject evaluatedResult = new JSONObject();
            evaluatedResult.put("name", project);
            evaluatedResult.put("value", 0);
            evaluatedResult.put("label", project);
            evaluatedResult.put("link", null);
            evaluatedResult.put("children", null);
            evaluatedResult.put("series", series);

            // add evaluated values
            metricValues.add(evaluatedResult);
        }
        projectMetric.setMetricValues(metricValues);

        return projectMetric;

    }


    public ProjectMetric defectAgeing(ProjectMetric projectMetric) throws Exception{


        String className = "JiraIssue";
        Class collectionClass = Class.forName("com.cts.idashboard.services.metricservice.data." + className);
        String[] timePeriods = {"e.Last 07 days","d.Last 15 days","c.Last 30 days","b.Last 2 months","a.Last 3 months"};
        JSONArray metricValues = new JSONArray();
        Date toDate = Date.from(Instant.now());
        Date fromDate = Date.from(Instant.now());

        for(String period: timePeriods){
            System.out.println("Time period ** "+period);

            if(period.equalsIgnoreCase("e.last 07 days")){
                fromDate = Date.from(Instant.now().minus(7, ChronoUnit.DAYS));
            }
            else if(period.equalsIgnoreCase("d.last 15 days")){
                toDate = fromDate;
                fromDate = Date.from(Instant.now().minus(15, ChronoUnit.DAYS));
            }
            else if(period.equalsIgnoreCase("c.last 30 days")){
                toDate = fromDate;
                fromDate = Date.from(Instant.now().minus(30, ChronoUnit.DAYS));
            }
            else if(period.equalsIgnoreCase("b.last 2 months")){
                toDate = Date.from(fromDate.toInstant());
                fromDate= Date.from(Instant.now());
                fromDate.setMonth((int) (fromDate.getMonth()-2));
            }
            else if(period.equalsIgnoreCase("a.last 3 months")){
                toDate = Date.from(fromDate.toInstant());
                fromDate= Date.from(Instant.now());
                fromDate.setMonth((int) (fromDate.getMonth()-3));
            }

            System.out.println("From date  : "+fromDate);
            System.out.println("To date  : "+toDate);

            Query query = new Query();
            Criteria criteria = null;

            // Applying project filter
            System.out.println("Jira projects applying custom function filter: " +projectMetric.getJiraProjects());
            if(projectMetric.getJiraProjects()!=null){
                if(!(projectMetric.getGrouping().equals("Yes") && projectMetric.getGroupBy().equals("projectName"))){
                    System.out.println("Project filter criteria applied");
                    criteria = Criteria.where("projectName").in(projectMetric.getJiraProjects());
                    if(criteria !=null)
                        query.addCriteria(criteria);
                }
                else{
                    System.out.println("Project filter criteria not applied");
                }
            }

            // Applying date filter
            criteria = Criteria.where("created").gte(fromDate).lte(toDate);
            if(criteria !=null){
                query.addCriteria(criteria);
            }

            // Applying defect ageing filter
            criteria = Criteria.where("statusCategoryName").ne("Done").orOperator(Criteria.where("reOpenFlag").ne("true"));
            if(criteria !=null){
                query.addCriteria(criteria);
            }
            int value = 0;
            JSONObject evaluatedResult = new JSONObject();
            if(projectMetric.getJiraProjects()!=null) {
                value = (int) Math.round(defectAgeingFormula(query, collectionClass));
            }
            System.out.println("Defect ageing value for the time period "+period+" is *"+value);
            System.out.println();
            evaluatedResult.put("groupName",period );
            evaluatedResult.put("result", value);

            // add evaluated values
            metricValues.add(evaluatedResult);
        }
        projectMetric.setMetricValues(metricValues);
        return projectMetric;
    }

    public ProjectMetric defectAgeingStack(ProjectMetric projectMetric) throws Exception{

        String className = "JiraIssue";
        Class collectionClass = Class.forName("com.cts.idashboard.services.metricservice.data." + className);
        String[] periodsList = {"Last 07 days","Last 15 days","Last 30 days","Last 2 months","Last 3 months"};
        JSONArray metricValues = new JSONArray();

        Date toDate = Date.from(Instant.now());
        Date fromDate = Date.from(Instant.now());
        JSONObject dateList = new JSONObject();

        for(String period: periodsList) {
            if (period.equalsIgnoreCase("last 07 days")) {
                fromDate = Date.from(Instant.now().minus(7, ChronoUnit.DAYS));
            } else if (period.equalsIgnoreCase("last 15 days")) {
                toDate = fromDate;
                fromDate = Date.from(Instant.now().minus(15, ChronoUnit.DAYS));
            } else if (period.equalsIgnoreCase("last 30 days")) {
                toDate = fromDate;
                fromDate = Date.from(Instant.now().minus(30, ChronoUnit.DAYS));
            } else if (period.equalsIgnoreCase("last 2 months")) {
                toDate = Date.from(fromDate.toInstant());
                fromDate = Date.from(Instant.now());
                fromDate.setMonth((int) (fromDate.getMonth() - 2));
            } else if (period.equalsIgnoreCase("last 3 months")) {
                toDate = Date.from(fromDate.toInstant());
                fromDate = Date.from(Instant.now());
                fromDate.setMonth((int) (fromDate.getMonth() - 3));
            }
            List<Date> date = new ArrayList<>();
            date.add(fromDate);
            date.add(toDate);
            dateList.put(period,date);
        }

        System.out.println("Date list :" +dateList);
        String[] timePeriods = {"Last 3 months","Last 2 months","Last 30 days","Last 15 days","Last 07 days",};

        for(String period: timePeriods) {
            System.out.println("*** TIME PERIOD : "+period+" ***");

            List<String> distinctPriorityValues = mongoOperation.findDistinct("priority", JiraIssue.class, String.class);

            System.out.println("Priority wise distinct data * "+distinctPriorityValues);

            JSONArray series =new JSONArray();

            for(String priority : distinctPriorityValues){
                List<Date> datesPeriodList = (List<Date>) dateList.get(period);
                System.out.println("From date : "+datesPeriodList.get(0));
                System.out.println("To date : "+datesPeriodList.get(1));
                fromDate = datesPeriodList.get(0);
                toDate = datesPeriodList.get(1);

                Query query = new Query();
                Criteria criteria = null;

                // Applying project filter
                System.out.println("Jira projects applying custom function filter: " +projectMetric.getJiraProjects());
                if(projectMetric.getJiraProjects()!=null){
                    if(!(projectMetric.getGrouping().equals("Yes") && projectMetric.getGroupBy().equals("projectName"))){
                        System.out.println("Project filter criteria applied");
                        criteria = Criteria.where("projectName").in(projectMetric.getJiraProjects());
                        if(criteria !=null)
                            query.addCriteria(criteria);
                    }
                    else{
                        System.out.println("Project filter criteria not applied");
                    }
                }

                // Applying date filter
                criteria = Criteria.where("created").gte(fromDate).lte(toDate);
                if(criteria !=null){
                    query.addCriteria(criteria);
                }

                // Applying defect ageing filter
                criteria = Criteria.where("statusCategoryName").ne("Done").orOperator(Criteria.where("reOpenFlag").ne("true"));
                if(criteria !=null){
                    query.addCriteria(criteria);
                }

                // Applying priority filter
                criteria = Criteria.where("priority").is(priority);
                if(criteria !=null){
                    query.addCriteria(criteria);
                }

                JSONObject evaluatedResult1 = new JSONObject();int value = 0;
                JSONObject evaluatedResult = new JSONObject();
                if(projectMetric.getJiraProjects()!=null) {
                    value = (int) Math.round(defectAgeingFormula(query, collectionClass));
                }
                System.out.println("Defect ageing value for priority "+priority+" with time period "+period+" is : "+value);
                System.out.println();

                evaluatedResult1.put("name", priority);
                evaluatedResult1.put("value", value);
                evaluatedResult1.put("label", priority);
                evaluatedResult1.put("link", null);
                evaluatedResult1.put("children", null);
                evaluatedResult1.put("series", null);

                series.add(evaluatedResult1);
            }

            JSONObject evaluatedResult = new JSONObject();
            evaluatedResult.put("name", period);
            evaluatedResult.put("value", 0);
            evaluatedResult.put("label", period);
            evaluatedResult.put("link", null);
            evaluatedResult.put("children", null);
            evaluatedResult.put("series", series);

            // add evaluated values
            metricValues.add(evaluatedResult);
        }
        projectMetric.setMetricValues(metricValues);
        return projectMetric;
    }


    public ProjectMetric defectAgeingLesserDuration(ProjectMetric projectMetric) throws Exception{

        String className = "JiraIssue";
        Class collectionClass = Class.forName("com.cts.idashboard.services.metricservice.data." + className);
        String[] timePeriods = {"e.Last day","d.Last 2 days","c.Last 4 days","b.Last week","a.Last 2 weeks"};
        JSONArray metricValues = new JSONArray();
        Date toDate = Date.from(Instant.now());
        Date fromDate = Date.from(Instant.now());

        for(String period: timePeriods){
            System.out.println("Time period : "+period);
            if(period.equalsIgnoreCase("e.Last day")){
                fromDate = Date.from(Instant.now().minus(1, ChronoUnit.DAYS));
            }
            else if(period.equalsIgnoreCase("d.Last 2 days")){
                toDate = fromDate;
                fromDate = Date.from(Instant.now().minus(2, ChronoUnit.DAYS));
            }
            else if(period.equalsIgnoreCase("c.Last 4 days")){
                toDate = fromDate;
                fromDate = Date.from(Instant.now().minus(4, ChronoUnit.DAYS));
            }
            else if(period.equalsIgnoreCase("b.Last week")){
                toDate = fromDate;
                fromDate = Date.from(Instant.now().minus(7, ChronoUnit.DAYS));
            }
            else if(period.equalsIgnoreCase("a.Last 2 weeks")){
                toDate = fromDate;
                fromDate = Date.from(Instant.now().minus(14, ChronoUnit.DAYS));
            }

            System.out.println("From date : "+fromDate);
            System.out.println("To date : "+toDate);

            Query query = new Query();
            Criteria criteria = null;

            // Applying project filter
            System.out.println("Jira projects applying custom function filter: " +projectMetric.getJiraProjects());
            if(projectMetric.getJiraProjects()!=null){
                if(!(projectMetric.getGrouping().equals("Yes") && projectMetric.getGroupBy().equals("projectName"))){
                    System.out.println("Project filter criteria applied");
                    criteria = Criteria.where("projectName").in(projectMetric.getJiraProjects());
                    if(criteria !=null)
                        query.addCriteria(criteria);
                }
                else{
                    System.out.println("Project filter criteria not applied");
                }
            }

            // Applying date filter
            criteria = Criteria.where("created").gte(fromDate).lte(toDate);
            if(criteria !=null){
                query.addCriteria(criteria);
            }

            // Applying defect ageing filter
            criteria = Criteria.where("statusCategoryName").ne("Done").orOperator(Criteria.where("reOpenFlag").ne("true"));
            if(criteria !=null){
                query.addCriteria(criteria);
            }

            int value = 0;
            JSONObject evaluatedResult = new JSONObject();
            if(projectMetric.getJiraProjects()!=null) {
                value = (int) Math.round(defectAgeingFormula(query, collectionClass));
            }
            System.out.println("Defect ageing agile value for "+period+" is * "+value);
            System.out.println();
            evaluatedResult.put("groupName",period );
            evaluatedResult.put("result", value);
            // add evaluated values
            metricValues.add(evaluatedResult);
        }
        projectMetric.setMetricValues(metricValues);

        return projectMetric;
    }


    public double defectAgeingFormula(Query query, Class className) throws Exception{

        Long valKey = mongoOperation.count(query, className);
        System.out.println("Collection used for query : "+className);
        System.out.println("Query applied : "+query);
        System.out.println("Count value : "+valKey);
        return valKey;
    }

}
