package com.cts.idashboard.services.metricservice.services;

import com.cts.idashboard.services.metricservice.data.MetricResults;
import com.cts.idashboard.services.metricservice.data.ProjectMetric;
import com.cts.idashboard.services.metricservice.data.SourceBotsDefects;
import com.cts.idashboard.services.metricservice.repos.*;
import com.fathzer.soft.javaluator.DoubleEvaluator;
import com.fathzer.soft.javaluator.StaticVariableSet;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.stereotype.Component;

import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.*;

@Component
public class CalculateBotsDefectsMetrics {

    @Autowired
    MetricConfigRepository metricRepo;

    @Autowired
    JiraIssueRepository jiraIssueRepository;

    @Autowired
    MetricsRepository metricsRepository;

    @Autowired
    DashboardRepository dashboardRepository;

    @Autowired
    SchedulerRunsRepository schedulerRunsRepository;

    @Autowired
    MongoOperations mongoOperation;

    @Autowired
    MetricFunctions metricFunctions;

    @Autowired
    TrendDateFormatter trendDateFormatter;


    public MetricResults calculateBotsMetrics(String metricName, ProjectMetric projectMetric,String SourceBotsDefects, String lobId, String orgId) throws Exception {


        DoubleEvaluator eval = new DoubleEvaluator();
        StaticVariableSet<Double> variableSet = new StaticVariableSet();
        int calculatedValue = 0;
        MetricResults metrics = null;
        JSONArray metricValues = new JSONArray();
        //  JSONArray trendingResult = new JSONArray();
        if(projectMetric.getTrending().equalsIgnoreCase("Yes")){
           // metricValues = trendDateFormatter.trendDateFormatMethod(metricName,projectMetric,SourceBotsDefects);
            //projectMetric.getTrendingMetric().addAll(trendDateFormatter.trendDateFormatMethod(metricName,projectMetric,SourceBotsDefects));
            projectMetric = trendDateFormatter.trendDateFormatMethod(metricName,projectMetric,SourceBotsDefects);

            //  projectMetric.setTrendResult(groupedResult);
            projectMetric.setMetricValues(metricValues);

        }
        else if (projectMetric.getGrouping().equalsIgnoreCase("Yes")) {
            List<String> distinctData = null;
            if (!(projectMetric.getGroupValue().equalsIgnoreCase("All"))) {
                distinctData = Arrays.asList(projectMetric.getGroupValue().split(","));
            } else {
                distinctData =mongoOperation.findDistinct(projectMetric.getGroupBy(), SourceBotsDefects.class, String.class);
            }
            System.out.println("distinctData --- " + distinctData);
            for (String distinctValue : distinctData) {
                calculatedValue = calculateMetricValue(metricName, distinctValue, projectMetric);
                JSONObject evaluatedResult = new JSONObject();
                evaluatedResult.put("groupName", distinctValue);
                evaluatedResult.put("result", calculatedValue);
                // groupedResult.add(evaluatedResult);
                metricValues.add(evaluatedResult);
            }
            // projectMetric.setGroupedResult(groupedResult);
            projectMetric.setMetricValues(metricValues);
        } else {
            calculatedValue = calculateMetricValue(metricName, null, projectMetric);
        }

        metrics = saveMetricResult(metricName, calculatedValue, projectMetric, lobId, orgId);
        return metrics;
    }

    public int calculateMetricValue(String metricName, String distinctValue, ProjectMetric projectMetric) throws Exception {

        String formula = projectMetric.getFormula();
        Map<String, JSONObject> formulaParams = projectMetric.getFormulaParams();
        System.out.println("formula in method- " + formula);
        DoubleEvaluator eval = new DoubleEvaluator();
        StaticVariableSet<Double> variableSet = new StaticVariableSet<Double>();
        Double result = 0.0;
        MetricResults metrics = null;

        String isGrouping = "No";

        if(distinctValue!= null){
            isGrouping="Yes";
        }

        for (Map.Entry<String, JSONObject> map : formulaParams.entrySet()) {
            System.out.println(map.getKey() + " " + map.getValue());
            Map<String, JSONObject> valueObjectMap = map.getValue();
            System.out.println("valueMap - " + valueObjectMap);
            for (Map.Entry<String, JSONObject> valObj : valueObjectMap.entrySet()) {
                System.out.println(valObj.getKey() + " ****** " + valObj.getValue());
                Map<String, String> valueMap = valObj.getValue();

                System.out.println("value Map -- ** -- " + valueMap);

                if(valObj.getKey().equals("count")) {
                    Long valKey = metricFunctions.count("SourceBotsDefects", valueMap.entrySet(), projectMetric, "No", isGrouping, null, null, distinctValue);
                    System.out.println("count value : "+valKey);
                    variableSet.set(map.getKey(), Double.valueOf(valKey));
                }
                else if(valObj.getKey().equals("countAnd")) {
                    Long valKey = metricFunctions.countAnd("SourceBotsDefects", valueMap.entrySet(), projectMetric,"No", isGrouping, null, null, distinctValue);
                    System.out.println("countAnd value : "+valKey);
                    variableSet.set(map.getKey(), Double.valueOf(valKey));
                }
                else if(valObj.getKey().equals("sum")){
                    Long valKey = metricFunctions.sum("SourceBotsDefects", valueMap.entrySet(), projectMetric, "No", isGrouping, null, null, distinctValue);
                    System.out.println("sum value : "+valKey);
                    variableSet.set(map.getKey(), valKey.doubleValue());
                }
                else if(valObj.getKey().equals("sumAnd")){
                    Long valKey = metricFunctions.sumAnd("SourceBotsDefects", valueMap.entrySet(), projectMetric, "No", isGrouping, null, null, distinctValue);
                    System.out.println("sumAnd value : "+valKey);
                    variableSet.set(map.getKey(), valKey.doubleValue());
                }
                else if(valObj.getKey().equals("avg")) {
                    Double valKey = metricFunctions.avg("SourceBotsDefects", valueMap.entrySet(), projectMetric, "No", isGrouping, null, null, distinctValue);
                    System.out.println("avg value : "+valKey);
                    variableSet.set(map.getKey(), valKey);
                }
                else if(valObj.getKey().equals("avgAnd")) {
                    Double valKey = metricFunctions.avgAnd("SourceBotsDefects", valueMap.entrySet(), projectMetric, "No", isGrouping, null, null, distinctValue);
                    System.out.println("avgAnd value : "+valKey);
                    variableSet.set(map.getKey(), valKey);
                }
                else if(valObj.getKey().equals("sumISO")){
                    Double valKey = metricFunctions.sumIS0("SourceBotsDefects", valueMap.entrySet(), projectMetric, "No", isGrouping, null, null, distinctValue);
                    System.out.println("sumISO value : "+valKey);
                    variableSet.set(map.getKey(), valKey);
                }
                else if(valObj.getKey().equals("sumISOAnd")){
                    Double valKey = metricFunctions.sumIS0And("SourceBotsDefects", valueMap.entrySet(), projectMetric, "No", isGrouping, null, null, distinctValue);
                    System.out.println("sumISOAnd value : "+valKey);
                    variableSet.set(map.getKey(), valKey);
                }
                else if(valObj.getKey().equals("sumISODiff")){
                    Double valKey = metricFunctions.sumIS0Diff("SourceBotsDefects", valueMap.entrySet(), projectMetric, "No", isGrouping, null, null, distinctValue);
                    System.out.println("sumISODiff value : "+valKey);
                    variableSet.set(map.getKey(), valKey);
                }
                else if(valObj.getKey().equals("sumISODiffAnd")){
                    Double valKey = metricFunctions.sumIS0DiffAnd("SourceBotsDefects", valueMap.entrySet(), projectMetric, "No", isGrouping, null, null, distinctValue);
                    System.out.println("sumISODiffAnd value : "+valKey);
                    variableSet.set(map.getKey(), valKey);
                }
                else if(valObj.getKey().equals("max")){
                    Long valKey = metricFunctions.max("SourceBotsDefects", valueMap.entrySet(), projectMetric, "No",isGrouping, null, null, distinctValue);
                    System.out.println("Max value : "+valKey);
                    variableSet.set(map.getKey(), valKey.doubleValue());
                }
                else if(valObj.getKey().equals("maxAnd")){
                    Long valKey = metricFunctions.maxAnd("SourceBotsDefects", valueMap.entrySet(), projectMetric, "No",isGrouping, null, null, distinctValue);
                    System.out.println("MaxAnd value : "+valKey);
                    variableSet.set(map.getKey(), valKey.doubleValue());
                }
                else if(valObj.getKey().equals("min")){
                    Long valKey = metricFunctions.min("SourceBotsDefects", valueMap.entrySet(), projectMetric, "No",isGrouping, null, null, distinctValue);
                    System.out.println("Min value : "+valKey);
                    variableSet.set(map.getKey(), valKey.doubleValue());
                }
                else if(valObj.getKey().equals("minAnd")){
                    Long valKey = metricFunctions.minAnd("SourceBotsDefects", valueMap.entrySet(), projectMetric, "No",isGrouping, null, null, distinctValue);
                    System.out.println("MinAnd value : "+valKey);
                    variableSet.set(map.getKey(), valKey.doubleValue());
                }
            }
        }
//        System.out.println("Variables  in method--  " + variableSet.get() + " " + variableSet.toString());
        result = eval.evaluate(formula, variableSet);
        System.out.println("Save - " + distinctValue);
        return (int)Math.round(result);
    }

    public MetricResults saveMetricResult(String metricName, int rejectionRate, ProjectMetric projectMetric, String lobId, String orgId) {
        //Optional<MetricResults> metricResults = metricsRepository.findByMetricNameAndDashboardNameAndPageNameAndItemId(metricName, projectMetric.getDashboardName(), projectMetric.getPageName(), projectMetric.getItemId());
        Optional<MetricResults> metricResults = metricsRepository.findByMetricNameAndDashboardNameAndItemId(metricName, projectMetric.getDashboardName(), projectMetric.getItemId());
        if (metricResults.isPresent()) {
            MetricResults metricResult = metricResults.get();

            if (projectMetric.getGrouping().equalsIgnoreCase("Yes")) {
                // metricResult.setGroupedResult(projectMetric.getGroupedResult());
                metricResult.setMetricValues(projectMetric.getMetricValues());
                metricResult.setGroupBy(projectMetric.getGroupBy());
                metricResult.setGrouping(projectMetric.getGrouping());
                metricResult.setGroupValue(projectMetric.getGroupValue());
                metricResult.setTrending(projectMetric.getTrending());
                metricResult.setTrendCount(projectMetric.getTrendCount());
                metricResult.setTrendBy(projectMetric.getTrendBy());
                metricResult.setTrendingField(projectMetric.getTrendingField());
            } else if(projectMetric.getTrending().equalsIgnoreCase("Yes")){
                metricResult.setTrendingMetricValues(projectMetric.getTrendingMetric());
                //metricResult.setMetricValues(projectMetric.getMetricValues());
                metricResult.setGroupBy(projectMetric.getGroupBy());
                metricResult.setGrouping(projectMetric.getGrouping());
                metricResult.setGroupValue(projectMetric.getGroupValue());
                metricResult.setTrending(projectMetric.getTrending());
                metricResult.setTrendCount(projectMetric.getTrendCount());
                metricResult.setTrendBy(projectMetric.getTrendBy());
                metricResult.setTrendingField(projectMetric.getTrendingField());

            }else {
                metricResult.setMetricValue(rejectionRate);
            }

            metricResult.setLastCalculatedDate(Instant.now());
            return metricsRepository.save(metricResult);
        } else {
            MetricResults metricResult = new MetricResults();
            metricResult.setMetricName(metricName);
            if (projectMetric.getGrouping().equalsIgnoreCase("Yes")) {
                // metricResult.setGroupedResult(projectMetric.getGroupedResult());
                metricResult.setMetricValues(projectMetric.getMetricValues());
                metricResult.setGroupBy(projectMetric.getGroupBy());
                metricResult.setGrouping(projectMetric.getGrouping());
                metricResult.setGroupValue(projectMetric.getGroupValue());
                metricResult.setTrending(projectMetric.getTrending());
                metricResult.setTrendCount(projectMetric.getTrendCount());
                metricResult.setTrendBy(projectMetric.getTrendBy());
                metricResult.setTrendingField(projectMetric.getTrendingField());
                //  metricResult.setGroupBy(projectMetric.getGroupBy());
            }  else if(projectMetric.getTrending().equalsIgnoreCase("Yes")){
                //metricResult.setMetricValues(projectMetric.getMetricValues());
                metricResult.setTrendingMetricValues(projectMetric.getTrendingMetric());
                metricResult.setGroupBy(projectMetric.getGroupBy());
                metricResult.setGrouping(projectMetric.getGrouping());
                metricResult.setGroupValue(projectMetric.getGroupValue());
                metricResult.setTrending(projectMetric.getTrending());
                metricResult.setTrendCount(projectMetric.getTrendCount());
                metricResult.setTrendBy(projectMetric.getTrendBy());
                metricResult.setTrendCount(projectMetric.getTrendCount());
                metricResult.setTrendingField(projectMetric.getTrendingField());


            }else {
                metricResult.setMetricValue(rejectionRate);
            }
            metricResult.setToolType("Bots");
            metricResult.setProjectName(projectMetric.getProjectName());
            metricResult.setItemId(projectMetric.getItemId());
            //metricResult.setPageName(projectMetric.getPageName());
            metricResult.setDashboardName(projectMetric.getDashboardName());
            metricResult.setCreatedDate(Instant.now());
            metricResult.setLobId(lobId);
            metricResult.setOrgId(orgId);
//            metricResult.setGroupValue(groupName);
            metricResult.setLastCalculatedDate(Instant.now());
            return metricsRepository.save(metricResult);

        }
    }
}
