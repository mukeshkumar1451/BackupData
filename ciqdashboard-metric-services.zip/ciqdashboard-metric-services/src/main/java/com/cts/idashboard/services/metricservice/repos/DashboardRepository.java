package com.cts.idashboard.services.metricservice.repos;

import com.cts.idashboard.services.metricservice.data.Dashboard;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;


public interface DashboardRepository extends MongoRepository<Dashboard, String> {


    Optional<Dashboard> findByProjectNameAndName(String projectName, String name);
}

//@Query(value = "{$and:[{'pages':{$elemMatch:{'name': :#{#pageName} }}},{'name': :#{#dashboardName}}]},{'pages.$':1,'name':1}")
//    Optional<Dashboard> findMetricsForDashboard(@Param("pageName") String pageName, @Param("dashboardName") String dashboardName);
//}