//package com.cts.idashboard.services.metricservice.data;
//
//import com.cts.idashboard.services.metricservice.util.DeleteDetailsDeserializer;
//import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
//import lombok.Data;
//
//import java.util.List;
//
//@Data
//@JsonDeserialize(using = DeleteDetailsDeserializer.class)
//public class ALMDeleteDetails {
//
//    private List<Delete> deleteComponents;
//    private int totalResults;
//
//}
