// package com.cts.idashboard.services.metricservice;

// import org.junit.jupiter.api.Test;
// import org.springframework.boot.test.context.SpringBootTest;

// @SpringBootTest
// class MetricServiceApplicationTests {

// 	@Test
// 	void contextLoads() {
// 	}

// }
