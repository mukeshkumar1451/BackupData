# Title
ciqdashboard-metric-services

# About the project
-- This project provides the analytical data of charts for various tools like Jira, ALM, Zephyr, Bots, Jenkins, Service Now, Rally, Git & Xray.
-- Data is fetched from the mongoDB for each tool & metric calculation will be done.

# Server backend features
Controller API: /api/metrics/calculate-metrics
-- This api will calculate the metric value for a chart based on the configuration having formula & formula params that are used inside functions.
-- This API will receive configuration information like tool name, dashboard name, project name etc
-- Based on the configuration, it will fetch required metric config having formula’s, formula param’s, functions etc.
-- Response contains metric calculation output.

# Calculation types:
Calculation will be done in three ways:
 1. Trend By
 This calculation is done if we want metric data for last 'n' no of weeks/months/years/days.
 2.	Group By
 This calculation is done based on grouping of a specific field considering distinct data of that field.
 3.	Without trending or grouping
 This calculation is done without considering any trending or grouping.

# Metric functions:
Metric functions will be used in metric formula. Every function have their own criteria.
1.	count:  It counts all the records present in the collection.
2.	countAnd:  It also counts the filtered records by giving specific conditions.
3.	Sum: It sum up the specific field value of all the records present in the collection.
4.	sumAnd:  It sum up the specific field value of the filtered records by giving specific conditions.
5.	avg: It gives average value of specific field of all the records present in the collection.
6.	avgAnd:  It gives average value of specific field of the filtered records by giving specific conditions.
7.	max:  It gives maximum value of specific field among all the records present in the collection.
8.	maxAnd:  It gives maximum value of specific field among the filtered records by giving specific conditions.
9.	min:  It gives minimum value of specific field among all the records present in the collection.
10.	minAnd:  It gives minimum value of specific field among the filtered records by giving specific conditions.
11.	sumISO:  It sum up the duration type field value (seconds) of all the records present in the collection and gives output in hours.
12.	sumISOAnd:  It sum up the duration type field value (seconds) of the filtered records by giving specific conditions and gives output in hours.
13.	sumISODiffAnd:  It sum up the difference of two ISO date fields of all the records present in the collection and gives output in hours.
14.	sumISODiffAnd:  It sum up the difference of two ISO date fields of the filtered records by giving specific conditions and gives output in hours.

# Basic flow
-- Authentication will be provided using the project "ciqdashboard-auth"
-- UI will get backend logic from the project "ciqdashboard-api"
-- ciqdashboard-api will take metric calculation value from this project "ciqdashboard-metric-service"
-- Each project will use the data present in mongoDB. Data will continuously fetch from the collector projects like JIRA, ALM etc

# Properties
Important configuration like server port, mongoDB url present inside “application.properties” file.

# How to run the project in local
Open the project in IDE. Then build & run it.
                        OR
Generate jar file & run the jar from the command prompt.
-- Command to Execute JAR file
java -jar <jar_name> --server.port=<serverName> --spring.data.mongodb.uri=mongodb://<DBUsername>:${spring.data.mongodb.credents}@<servername>:              <DBPort>/<DBname> --spring.data.mongodb.credents=ENC(JasyptEncryptedDBPassword) --jasypt.encryptor.password=<Base64EncodeKey>
-- How to generate jar file:
Go to project path inside command prompt & run the command “gradlew clean build”
  
  
 
  
  




