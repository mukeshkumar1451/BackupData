# Title
ciqdashboard-api

# About the project
This Project is mainly to create the charts.
-- A key benefit of charts is that they allow you to keep track of trends. This is critical in any business, and it helps you see where things might be growing or faltering.  
-- Charts are designed to assist you with monitoring and identifying trends. This allows you to keep an eye on areas of growth or concern. By doing so, you can make quick, yet informed decisions for your business.
-- You’ll also notice that charts and graphs help you store and organize large data quantities. This can be a huge help for companies that are unable to keep up with all their figures. By creating a chart or graph with the statistics, you’ll get a better understanding of how things are going.
-- CIQD dashboard project contains several types of charts there are:
    1.AREA charts
    2.BAR charts
    3.COMBO charts
    4.Fusion charts
    5.Gauge charts
    6.Line charts
    7.Pie charts and other type charts.
-- CIQD dashboard Java project is acts like glue between the user interface and database. java project contains business logics and provides the data flow in certain format.
-- This project will get metric calculation values from the project ‘Metric-Services’ which is having all logic about calculation part along with metric functions.

# Basic flow
-- Authentication will be provided using the project "ciqdashboard-auth"
-- UI will get backend logic from this project "ciqdashboard-api"
-- ciqdashboard-api will take metric calculation value from the project "ciqdashboard-metric-service"
-- Each project will use the data present in mongoDB. Data will continuously fetch from the collector projects like JIRA, ALM etc

# Properties
Important configuration like server port, mongoDB url & also authentication properties present inside “application.properties” file.

# How to run the project in local
Open the project in IDE. Then build & run it.
                    OR
Generate jar file & run the jar from the command prompt.
-- Command to Execute JAR file
    java -jar <jar_name> --server.port=<serverName> --spring.data.mongodb.uri=mongodb://<DBUsername>:${spring.data.mongodb.credents}@<servername>:              <DBPort>/<DBname> --spring.data.mongodb.credents=ENC(JasyptEncryptedDBPassword) --jasypt.encryptor.password=<Base64EncodeKey>
-- How to generate jar file:
    Go to project path inside command prompt & run the command “gradlew clean build”
  
  
 
  
  






