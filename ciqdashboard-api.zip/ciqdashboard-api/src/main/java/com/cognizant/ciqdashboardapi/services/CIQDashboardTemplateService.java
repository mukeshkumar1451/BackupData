package com.cognizant.ciqdashboardapi.services;


import com.cognizant.ciqdashboardapi.models.CIQDashboardTemplate;
import com.cognizant.ciqdashboardapi.repos.CIQDashboardTemplateRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CIQDashboardTemplateService {
    @Autowired
    CIQDashboardTemplateRepository dashboardTemplateRepository;

    public List<CIQDashboardTemplate> getAllTemplates(String category) throws Exception {
        if (category.equalsIgnoreCase("undefined")) {
            return dashboardTemplateRepository.findAll();
        }
        List<CIQDashboardTemplate> templateList = dashboardTemplateRepository.findByCategory(category);
        if (templateList.isEmpty()) {
            throw new Exception("No Templates found!!");
        }
        return templateList;
    }

    public List<CIQDashboardTemplate> getAllTemplates() throws Exception {

        List<CIQDashboardTemplate> templateList = dashboardTemplateRepository.findAll();
        if (templateList.isEmpty()) {
            throw new Exception("No Templates found!!");
        }
        return templateList;
    }
}
