/*
 *   © [2021] Cognizant. All rights reserved.
 *
 *     Licensed under the Apache License, Version 2.0 (the "License");
 *     you may not use this file except in compliance with the License.
 *     You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *     Unless required by applicable law or agreed to in writing, software
 *     distributed under the License is distributed on an "AS IS" BASIS,
 *     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *     See the License for the specific language governing permissions and
 *     limitations under the License.
 */

package com.cognizant.ciqdashboardapi.services;

import com.cognizant.ciqdashboardapi.errors.InvalidDetailsException;
import com.cognizant.ciqdashboardapi.errors.ResourceNotFoundException;
import com.cognizant.ciqdashboardapi.models.*;
import com.cognizant.ciqdashboardapi.models.chart.data.*;
import com.cognizant.ciqdashboardapi.repos.*;
import com.cognizant.ciqdashboardapi.repos.impl.IDChartItemRepositoryImpl;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/**
 * IDChartItemService
 *
 * @author Cognizant
 */

@Service
public class IDChartItemService {

    @Autowired
    IDChartItemRepository repository;
    @Autowired
    IDChartItemRepositoryImpl repositoryImpl;
    @Autowired
    ChartAggregationComponent chartAggregationComponent;
    @Autowired
    MetricsRepository metricRepo;

    @Autowired
    MetricConfigRepository metricConfigRepository;

    @Autowired
    CIQDashboardProjectRepository cIQDashboardProjectRepository;

    @Autowired
    CIQDashboardRepository ciqDashboardRepository;

    public List<IDChartItem> getAll() {
        return repository.findAll();
    }

    public List<IDChartItem> getAllByCategory(String category) {

        return repository.findByCategory(category);
    }

    public Optional<IDChartItem> get(String id) {
        return repository.findById(id);
    }

    public IDChartItem assertAndGet(String id) {
        Optional<IDChartItem> optional = get(id);
        if (optional.isPresent()) {
            return optional.get();
        } else {
            throw new ResourceNotFoundException("ChartItem", "id", id);
        }
    }

//    public IDChartItemDataDTO getChartData(String id, Optional<List<FilterConfig>> filters) {
//        IDChartItem chartItem = assertAndGet(id);
//        if (filters.isPresent()){
//            chartItem.getFilters().addAll(filters.get());
//        }
//
//        return chartAggregationComponent.getChartAggregation(chartItem);
//    }

    public IDChartItemDataDTO getChartData(String id, String projectName, String dashboardName, String category, String lobId, String orgId, Optional<List<FilterConfig>> filters) throws Exception {
        IDChartItem chartItem = assertAndGet(id);
        System.err.println("******************## Chart Item --- " + chartItem + "projectName - " + projectName);

        if (filters.isPresent()) {
            chartItem.getFilters().addAll(filters.get());
        }

       if (chartItem.getSource().equalsIgnoreCase("metrics")) {
            System.out.println("** Source is metrics ** ");
            IDChartItemDataDTO chartDTO = null;
            ChartData chartDataForAggregation = null;

            try {
                chartDTO = chartAggregationComponent.getChartAggregation(chartItem);
                if (chartDTO.getChartData() != null) {
                    chartDataForAggregation = chartDTO.getChartData().get(0);
                }
                System.out.println("Get chartDataForAggreagtion "+chartDataForAggregation);
            }
            catch (Exception ignore){System.out.println("ChartdataAggregation exception ignored: "+ignore);}

            System.out.println("$$$$$$$$$$$$$$$$$$$$ chartDTO- " + chartDTO);
            System.out.println("ChartData from aggregationComponenet dataDTO is : " + chartDataForAggregation);
            IDChartItemDataDTO dataDTO = null;

            if (category.equalsIgnoreCase("lob")) {
                if (lobId != null) {
                    dataDTO = getMetricDataByLOB(chartItem.getId(), lobId, dashboardName, chartDataForAggregation);
                }
            } else if (category.equalsIgnoreCase("org")) {
                if (orgId != null) {
                    dataDTO = getMetricDataByORG(chartItem.getId(), orgId, dashboardName, chartDataForAggregation);
                }
            } else {
                Optional<MetricConfig> metricConfig = metricConfigRepository.findByMetricName(chartItem.getMetricName());
                System.err.println("$$$$$$$$$$$ - " + metricConfig);
                if (metricConfig.isPresent()) {
                    MetricConfig metric = metricConfig.get();
                    dataDTO = getMetricData(chartItem.getId(), metric.getMetricName(), metric.getGrouping(), metric.getTrending(), metric.getCustomFunction(), metric.getCustomFunctionName(), projectName, dashboardName);
                }
            }return dataDTO;
        } else {
            if (category.equalsIgnoreCase("lob")) {
                System.out.println("ID chart item LOB");
                IDChartItemDataDTO idChartItemDataDTO = chartAggregationComponent.getChartAggregation(chartItem);
                System.out.println("Chart Data DTO "+idChartItemDataDTO);
                Object chartData = null;
                if (chartItem.getType().equalsIgnoreCase("bar-vertical-chart-fusion")) {
                    List<CIQDashboardProject> cIQDashboardProject = cIQDashboardProjectRepository.findByLobId(lobId);
                    chartData = idChartItemDataDTO.getData();
                    Gson gson = new Gson();
                    String json = gson.toJson(chartData);
                    System.out.println("json" + json);
                    for (int j = 0; j < cIQDashboardProject.size(); j++) {
                        List<CIQDashboard> ciqDashboard = ciqDashboardRepository.findByProjectName(cIQDashboardProject.get(j).getName());
                        if (ciqDashboard.size() != 0) {
                            String dashboardId = ciqDashboard.get(0).getId();
                            // String link = projectUrl+"/ciqdashboard/#/ciqdashboard/" + cIQDashboardProject.get(j).getId() + "/dashboards/" + dashboardId+";page=0?category=project";
                            //  String link = "http://10.120.100.97/ciqdashboard/#/ciqdashboard/" + cIQDashboardProject.get(j).getId() + "/dashboards/" + dashboardId+";page=0?category=project";
                            //String link = "http://10.120.100.95/ciqdashboard/#/ciqdashboard/" + cIQDashboardProject.get(j).getId() + "/dashboards/" + dashboardId+";page=0?category=project";
                            String link = cIQDashboardProject.get(j).getId() + "/dashboards/" + dashboardId + ";page=0?category=project";
                            System.out.println("linkforTest" + link);
                            json = replaceFirstOccurrenceOfString(json, "#url#", link);
                            System.out.println("replacejson" + json);
                        }
                    }
                    //  return idChartItemDataDTO;
                    final GsonBuilder gsonBuilder = new GsonBuilder();
                    final Gson gson1 = gsonBuilder.create();
                    ChartDataForFusion[] chartDataForFusions = gson1.fromJson(json, ChartDataForFusion[].class);
                    idChartItemDataDTO.setData(chartDataForFusions);
                }
                return idChartItemDataDTO;
            }
            return chartAggregationComponent.getChartAggregation(chartItem);
        }
    }

    public static String replaceFirstOccurrenceOfString(String input, String stringToReplace,
                                                        String stringToReplaceWith) {
        if (input == null || input.isEmpty()) {
            return "";
        }
        if (stringToReplace == null || stringToReplace.isEmpty() || stringToReplaceWith == null
                || stringToReplaceWith.isEmpty()) {
            return input;
        }
        String result = input.replaceFirst(Pattern.quote(stringToReplace), stringToReplaceWith);
        return result;
    }


    public List<IDChartItem> searchByNames(List<String> names) {
        return repositoryImpl.findByNameLikeIgnoreCase(names);
    }

    public IDChartItemDataDTO preview(IDChartItem chartItem) throws NoSuchFieldException, IllegalAccessException {
        assertAndGetChartItemType(chartItem.getType());
        return chartAggregationComponent.getChartAggregation(chartItem);
    }

    public IDChartItem add(IDChartItem chartItem) {
        assertInsert(chartItem);
        assertAndGetChartItemType(chartItem.getType());
        if (chartItem.getSource().equalsIgnoreCase("metrics")) {
//            chartItem.setMetricCategory("derived");
//            if (chartItem.getMetricName() == null || chartItem.getMetricName().isEmpty()) {
//                throw new InvalidDetailsException(String.format("Empty/blank Metric Name", chartItem.getMetricName()));
//            }
        }
        return repository.insert(chartItem);
    }

    public IDChartItem update(IDChartItem chartItem) {
        assertAndGet(chartItem.getId());
        assertAndGetChartItemType(chartItem.getType());
        return repository.save(chartItem);
    }

    public void deleteById(String id) {
        assertAndGet(id);
        repository.deleteById(id);
    }

    public void deleteByIdIn(List<String> ids) {
        repository.deleteByIdIn(ids);
    }

    private void assertInsert(IDChartItem chartItem) {
        if (!StringUtils.isEmpty(chartItem.getId())) {
            throw new InvalidDetailsException("Id should be null/empty");
        }
    }

    private Type.ChartItemType assertAndGetChartItemType(String type) {
        Optional<Type.ChartItemType> optional = Type.ChartItemType.getChartItemType(type);
        if (optional.isPresent()) {
            return optional.get();
        } else {
            throw new InvalidDetailsException(String.format("invalid chart type(%s) provided", type));
        }
    }


//    public IDChartItemDataDTO getMetricData(String id, String projectName, String dashboardName, ChartData data1) {
//        IDChartItem chartItem = assertAndGet(id);
//        System.out.println("chartItem -*-*-*- " + chartItem);
//        List<ChartData> data = new ArrayList<>();
//        IDChartItemDataDTO dataDTO = new IDChartItemDataDTO();
//        SourceMetrics metrics = metricRepo.findByProjectNameAndDashboardNameAndItemId(projectName, dashboardName, id);
//        System.out.println("metrics -*-*-*- " + metrics);
//        data.add(new ChartData(metrics.getMetricName(), metrics.getMetricValue(), data1.getChildren(), data1.getSeries()));
//        dataDTO.setChartItemDetails(chartItem);
//        dataDTO.setData(data);
//        return dataDTO;
//    }

    public IDChartItemDataDTO getMetricData(String itemId, String metricName, String grouping, String trending, String customFunction, String customFunctionName, String projectName, String dashboardName) throws Exception {

        System.out.println("** Project Data **");
        IDChartItem chartItem = assertAndGet(itemId);
        System.out.println("chartItem -*-*-*- " + chartItem);

        List<ChartData> data = new ArrayList<>();
        List<ChartDataTrending> dataTrending = new ArrayList<>();
        IDChartItemDataDTO dataDTO = new IDChartItemDataDTO();

        //SourceMetrics metrics = metricRepo.findByProjectNameAndDashboardNameAndItemId(projectName, dashboardName, itemId);
        Optional<SourceMetrics> metrics1 = metricRepo.findByProjectNameAndDashboardNameAndItemIdAndMetricName(projectName, dashboardName, itemId, metricName);
        System.out.println("metrics is present : " + metrics1.isPresent());

        if (metrics1.isPresent()) {
            SourceMetrics metrics = metrics1.get();
            System.out.println("Source metrics fetched is : "+metrics);
            if ("yes".equalsIgnoreCase(grouping)) {
                if(chartItem.getType().equalsIgnoreCase("bar-vertical-chart-fusion")){
                    String calculatedResults = metrics.getMetricValues().toJSONString();
                    JSONArray array = (JSONArray) new JSONParser().parse(calculatedResults);
                    for (int i = 0; i < array.size(); i++) {
                        JSONObject result = (JSONObject) array.get(i);
                        String linkValue = null;
                        if(result.get("link")!=null){
                            linkValue = result.get("link").toString();
                        }
                        else{
                            linkValue = "";
                        }
                        data.add(new ChartData(result.get("groupName").toString(), result.get("result"), result.get("groupName").toString(), linkValue, null, null));
                    }
                }
                else {
                    String calculatedResults = metrics.getMetricValues().toJSONString();
                    JSONArray array = (JSONArray) new JSONParser().parse(calculatedResults);
                    for (int i = 0; i < array.size(); i++) {
                        JSONObject result = (JSONObject) array.get(i);
                        data.add(new ChartData(result.get("groupName").toString(), result.get("result"), null, null, null, null));
                    }
                }if (data.size() > 0) {
                    Collections.sort(data, new SortByName());
                }dataDTO.setChartItemDetails(chartItem);
                dataDTO.setData(data);
            } else if ("yes".equalsIgnoreCase(trending)) {
                List<TrendingMetric> calculatedResults = metrics.getTrendingMetricValues();
                SimpleDateFormat inputDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
                calculatedResults.forEach(calculatedResult -> {
                    Date month = calculatedResult.getMonth();
                    Integer result = calculatedResult.getResult();
                    SimpleDateFormat outputDateFormat = new SimpleDateFormat("EEE MMM dd hh:mm:ss z yyyy");
                    //SimpleDateFormat outputDateFormat = new SimpleDateFormat("EEE d MMM, yyyy");
                    String outputDateString = outputDateFormat.format(month);
                    dataTrending.add(new ChartDataTrending(outputDateString, result));
                });
                dataDTO.setChartItemDetails(chartItem);
                dataDTO.setData(dataTrending);
            } else if ("yes".equalsIgnoreCase(customFunction)) {
                String calculatedResults = metrics.getMetricValues().toJSONString();
                JSONArray array = (JSONArray) new JSONParser().parse(calculatedResults);
                if (customFunctionName.equalsIgnoreCase("defect_ageing")) {
                    System.out.println("DEFECT AGEING FUNCTION ** ");
                    for (int i = 0; i < array.size(); i++) {
                        JSONObject result = (JSONObject) array.get(i);
                        data.add(new ChartData(result.get("groupName").toString(), result.get("result"), null, null, null, null));
                    }
                    if (data.size() > 0) {
                        Collections.sort(data, new SortByName());
                    }
                    dataDTO.setChartItemDetails(chartItem);
                    dataDTO.setData(data);
                } else if (customFunctionName.equalsIgnoreCase("defect_ageing_agile")) {
                    System.out.println("DEFECT AGEING AGILE FUNCTION ** ");
                    for (int i = 0; i < array.size(); i++) {
                        JSONObject result = (JSONObject) array.get(i);
                        data.add(new ChartData(result.get("groupName").toString(), result.get("result"), null, null, null, null));
                    }
                    if (data.size() > 0) {
                        Collections.sort(data, new SortByName());
                    }
                    dataDTO.setChartItemDetails(chartItem);
                    dataDTO.setData(data);
                } else if (customFunctionName.equalsIgnoreCase("defect_ageing_stack")) {
                    System.out.println("DEFECT AGEING STACK FUNCTION ** ");
                    for (int i = 0; i < array.size(); i++) {
                        JSONObject result = (JSONObject) array.get(i);
                        data.add(new ChartData(result.get("name").toString(), result.get("value"), result.get("label").toString(), null, null, (List<ChartData>) result.get("series")));
                    }if (data.size() > 0) {
                        Collections.sort(data, new SortByName());
                    }dataDTO.setChartItemDetails(chartItem);
                    dataDTO.setData(data);
                }else if (customFunctionName.equalsIgnoreCase("execution_progress")) {
                    System.out.println("EXECUTION PROGRESS FUNCTION ** ");
                    for (int i = 0; i < array.size(); i++) {
                        JSONObject result = (JSONObject) array.get(i);
                        data.add(new ChartData(result.get("name").toString(), result.get("value"), result.get("label").toString(), null, null, (List<ChartData>) result.get("series")));
                    }
                    if (data.size() > 0) {
                        Collections.sort(data, new SortByName());
                    }
                    Map<String, List<Value>> mappedvalues = new HashMap<>();
                    Categories categoriesData = new Categories();
                    for(ChartData data2 :data){
                        Map<String,Integer> value = new HashMap<>();
                        categoriesData.getCategory().add(
                                new Category().setLabel(data2.getName())
                        );

                        ListIterator seriesDataMap = data2.getSeries().listIterator();
                        while(seriesDataMap.hasNext()){
                            JSONObject  seriesData = (JSONObject) seriesDataMap.next();
                            String seriesName = seriesData.get("name").toString();
                            if(mappedvalues.get(seriesName) == null){
                                mappedvalues.put(seriesName,new LinkedList<>());
                            }
                            if(seriesData.get("link")!=null) {
                                mappedvalues.get(seriesName).add(new Value().setValue(Integer.valueOf(seriesData.get("value").toString()), seriesData.get("link").toString()));
                            }else {
                                mappedvalues.get(seriesName).add(new Value().setValue(Integer.valueOf(seriesData.get("value").toString()), ""));
                            }
                        };
                    };
                    List<Map> transformedData = mappedvalues.keySet().stream().sorted().map(key->{
                        Map<String,Object>  data3 = new LinkedHashMap<>();
                        data3.put("seriesName",key);
                        data3.put("data",mappedvalues.get(key));
                        return data3;
                    }).collect(Collectors.toList());
                    StackedFusionChartData stackedFusionChartData = new StackedFusionChartData("#chart_ui_data", List.of(categoriesData),transformedData);
                    JSONArray jsonArray1 = new JSONArray();
                    jsonArray1.add(stackedFusionChartData);
                    dataDTO.setChartItemDetails(chartItem);
                    dataDTO.setData(jsonArray1);
                }else if (customFunctionName.equalsIgnoreCase("quality_metrics")) {
                    System.out.println("QUALITY METRICS FUNCTION ** ");
                    for (int i = 0; i < array.size(); i++) {
                        JSONObject result = (JSONObject) array.get(i);
                        data.add(new ChartData(result.get("name").toString(), result.get("value"), result.get("label").toString(), null, null, (List<ChartData>) result.get("series")));
                    }
                    if (data.size() > 0) {
                        Collections.sort(data, new SortByName());
                    }
                    Map<String, List<Value>> mappedvalues = new HashMap<>();
                    Categories categoriesData = new Categories();
                    for(ChartData data2 :data){
                        Map<String,Integer> value = new HashMap<>();
                        categoriesData.getCategory().add(
                                new Category().setLabel(data2.getName())
                        );

                        ListIterator seriesDataMap = data2.getSeries().listIterator();
                        while(seriesDataMap.hasNext()){
                            JSONObject  seriesData = (JSONObject) seriesDataMap.next();
                            String seriesName = seriesData.get("name").toString();
                            if(mappedvalues.get(seriesName) == null){
                                mappedvalues.put(seriesName,new LinkedList<>());
                            }
                            if(seriesData.get("link")!=null) {
                                mappedvalues.get(seriesName).add(new Value().setValue(Integer.valueOf(seriesData.get("value").toString()), seriesData.get("link").toString()));
                            }else {
                                mappedvalues.get(seriesName).add(new Value().setValue(Integer.valueOf(seriesData.get("value").toString()), ""));
                            }
                        };
                    };
                    List<Map> transformedData = mappedvalues.keySet().stream().sorted().map(key->{
                        Map<String,Object>  data3 = new LinkedHashMap<>();
                        data3.put("seriesName",key);
                        data3.put("data",mappedvalues.get(key));
                        return data3;
                    }).collect(Collectors.toList());
                    StackedFusionChartData stackedFusionChartData = new StackedFusionChartData("#chart_ui_data", List.of(categoriesData),transformedData);
                    JSONArray jsonArray1 = new JSONArray();
                    jsonArray1.add(stackedFusionChartData);
                    dataDTO.setChartItemDetails(chartItem);
                    dataDTO.setData(jsonArray1);
                }
            } else {
                data.add(new ChartData(metrics.getMetricName(), metrics.getMetricValue(), null, null, null, null));
                if (data.size() > 0) {
                    Collections.sort(data, new SortByName());
                }
                dataDTO.setChartItemDetails(chartItem);
                dataDTO.setData(data);
            }
        }
        System.out.println(dataDTO);
        return dataDTO;
    }


    public IDChartItemDataDTO getMetricDataByLOB(String id, String lobId, String dashboardName, ChartData data1) throws ParseException {
        System.out.println("** LOB data **");
        IDChartItem chartItem = assertAndGet(id);
        System.out.println("chartItem -*-*-*- " + chartItem);

        List<ChartData> data = new ArrayList<>();
        IDChartItemDataDTO dataDTO = new IDChartItemDataDTO();
        List<ChartDataTrending> dataTrending = new ArrayList<>();

        Optional<MetricConfig> metricConfig = metricConfigRepository.findByMetricName(chartItem.getMetricName());
        System.err.println("$$$$$$$$$$$ - " + metricConfig);

        if (metricConfig.isPresent()) {
            MetricConfig metricConfig1 = metricConfig.get();
            String grouping = metricConfig1.getGrouping();
            String trending = metricConfig1.getTrending();
            String customFunction = metricConfig1.getCustomFunction();
            String customFunctionName = metricConfig1.getCustomFunctionName();

            Optional<SourceMetrics> metrics1 = metricRepo.findByLobIdAndDashboardNameAndItemIdAndMetricName(lobId,dashboardName,id, metricConfig1.getMetricName());
            System.out.println("Source metrics is present ** " + metrics1.isPresent());

            if (metrics1.isPresent()) {
                SourceMetrics metrics = metrics1.get();
                System.out.println("Source metrics fetched is : " + metrics);
                if ("yes".equalsIgnoreCase(grouping)) {
                    if(chartItem.getType().equalsIgnoreCase("bar-vertical-chart-fusion")){
                        String calculatedResults = metrics.getMetricValues().toJSONString();
                        JSONArray array = (JSONArray) new JSONParser().parse(calculatedResults);
                        for (int i = 0; i < array.size(); i++) {
                            JSONObject result = (JSONObject) array.get(i);
                            String linkValue = null;
                            if(result.get("link")!=null){
                                linkValue = result.get("link").toString();
                            }
                            else{
                                linkValue ="";
                            }
                            data.add(new ChartData(result.get("groupName").toString(), result.get("result"), result.get("groupName").toString(), linkValue, null, null));
                        }
                        if (data.size() > 0) {
                            Collections.sort(data, new SortByName());
                        }
                        dataDTO.setChartItemDetails(chartItem);
                        dataDTO.setData(data);
                    }
                    else {
                        String calculatedResults = metrics.getMetricValues().toJSONString();
                        JSONArray array = (JSONArray) new JSONParser().parse(calculatedResults);
                        for (int i = 0; i < array.size(); i++) {
                            JSONObject result = (JSONObject) array.get(i);
                            data.add(new ChartData(result.get("groupName").toString(), result.get("result"), null, null, null, null));
                        }
                        if (data.size() > 0) {
                            Collections.sort(data, new SortByName());
                        }dataDTO.setChartItemDetails(chartItem);
                        dataDTO.setData(data);
                    }
                } else if ("yes".equalsIgnoreCase(trending)) {
                    // String calculatedResults = metrics.getGroupedResult().toJSONString();
                    List<TrendingMetric> calculatedResults = metrics.getTrendingMetricValues();
                    SimpleDateFormat inputDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
                    calculatedResults.forEach(calculatedResult -> {
                        Date month = calculatedResult.getMonth();
                        Integer result = calculatedResult.getResult();
                        SimpleDateFormat outputDateFormat = new SimpleDateFormat("EEE MMM dd hh:mm:ss z yyyy");
                        //SimpleDateFormat outputDateFormat = new SimpleDateFormat("EEE d MMM, yyyy");
                        String outputDateString = outputDateFormat.format(month);
                        dataTrending.add(new ChartDataTrending(outputDateString, result));
                    });
                    dataDTO.setChartItemDetails(chartItem);
                    dataDTO.setData(dataTrending);
                } else if ("yes".equalsIgnoreCase(customFunction)) {
                    String calculatedResults = metrics.getMetricValues().toJSONString();
                    JSONArray array = (JSONArray) new JSONParser().parse(calculatedResults);
                    System.out.println("Calculates results ** " + calculatedResults);
                    if (customFunctionName.equalsIgnoreCase("defect_ageing")) {
                        System.out.println("DEFECT AGEING FUNCTION ** ");
                        for (int i = 0; i < array.size(); i++) {
                            JSONObject result = (JSONObject) array.get(i);
                            data.add(new ChartData(result.get("groupName").toString(), result.get("result"), null, null, null, null));
                        }
                        if (data.size() > 0) {
                            Collections.sort(data, new SortByName());
                        }
                        dataDTO.setChartItemDetails(chartItem);
                        dataDTO.setData(data);
                    } else if (customFunctionName.equalsIgnoreCase("defect_ageing_agile")) {
                        System.out.println("DEFECT AGEING AGILE FUNCTION ** ");
                        for (int i = 0; i < array.size(); i++) {
                            JSONObject result = (JSONObject) array.get(i);
                            data.add(new ChartData(result.get("groupName").toString(), result.get("result"), null, null, null, null));
                        }
                        if (data.size() > 0) {
                            Collections.sort(data, new SortByName());
                        }
                        dataDTO.setChartItemDetails(chartItem);
                        dataDTO.setData(data);
                    } else if (customFunctionName.equalsIgnoreCase("defect_ageing_stack")) {
                        System.out.println("DEFECT AGEING STACK FUNCTION ** ");
                        for (int i = 0; i < array.size(); i++) {
                            JSONObject result = (JSONObject) array.get(i);
                            data.add(new ChartData(result.get("name").toString(), result.get("value"), result.get("label").toString(), null, null, (List<ChartData>) result.get("series")));
                        }
                        if (data.size() > 0) {
                            Collections.sort(data, new SortByName());
                        }
                        dataDTO.setChartItemDetails(chartItem);
                        dataDTO.setData(data);
                    }else if (customFunctionName.equalsIgnoreCase("execution_progress")) {
                        System.out.println("EXECUTION PROGRESS FUNCTION ** ");
                        for (int i = 0; i < array.size(); i++) {
                            JSONObject result = (JSONObject) array.get(i);
                            data.add(new ChartData(result.get("name").toString(), result.get("value"), result.get("label").toString(), null, null, (List<ChartData>) result.get("series")));
                        }
                        if (data.size() > 0) {
                            Collections.sort(data, new SortByName());
                        }
                        Map<String, List<Value>> mappedvalues = new HashMap<>();
                        Categories categoriesData = new Categories();
                        for(ChartData data2 :data){
                            Map<String,Integer> value = new HashMap<>();
                            categoriesData.getCategory().add(
                                    new Category().setLabel(data2.getName())
                            );

                            ListIterator seriesDataMap = data2.getSeries().listIterator();
                            while(seriesDataMap.hasNext()){
                                JSONObject  seriesData = (JSONObject) seriesDataMap.next();
                                String seriesName = seriesData.get("name").toString();
                                if(mappedvalues.get(seriesName) == null){
                                    mappedvalues.put(seriesName,new LinkedList<>());
                                }
                                if(seriesData.get("link")!=null) {
                                    mappedvalues.get(seriesName).add(new Value().setValue(Integer.valueOf(seriesData.get("value").toString()), seriesData.get("link").toString()));
                                }else {
                                    mappedvalues.get(seriesName).add(new Value().setValue(Integer.valueOf(seriesData.get("value").toString()), ""));
                                }
                            };
                        };
                        List<Map> transformedData = mappedvalues.keySet().stream().sorted().map(key->{
                            Map<String,Object>  data3 = new LinkedHashMap<>();
                            data3.put("seriesName",key);
                            data3.put("data",mappedvalues.get(key));
                            return data3;
                        }).collect(Collectors.toList());
                        StackedFusionChartData stackedFusionChartData = new StackedFusionChartData("#chart_ui_data", List.of(categoriesData),transformedData);
                        JSONArray jsonArray1 = new JSONArray();
                        jsonArray1.add(stackedFusionChartData);
                        dataDTO.setData(jsonArray1);
                        dataDTO.setChartItemDetails(chartItem);
                    }else if (customFunctionName.equalsIgnoreCase("quality_metrics")) {
                        System.out.println("QUALITY METRICS FUNCTION ** ");
                        for (int i = 0; i < array.size(); i++) {
                            JSONObject result = (JSONObject) array.get(i);
                            System.out.println(result);
                            data.add(new ChartData(result.get("name").toString(), result.get("value"), result.get("label").toString(), null, null, (List<ChartData>) result.get("series")));
                        }
                        if (data.size() > 0) {
                            Collections.sort(data, new SortByName());
                        }
                        Map<String, List<Value>> mappedvalues = new HashMap<>();
                        Categories categoriesData = new Categories();
                        for(ChartData data2 :data){
                            Map<String,Integer> value = new HashMap<>();
                            categoriesData.getCategory().add(
                                    new Category().setLabel(data2.getName())
                            );

                            ListIterator seriesDataMap = data2.getSeries().listIterator();
                            while(seriesDataMap.hasNext()){
                                JSONObject  seriesData = (JSONObject) seriesDataMap.next();
                                String seriesName = seriesData.get("name").toString();
                                if(mappedvalues.get(seriesName) == null){
                                    mappedvalues.put(seriesName,new LinkedList<>());
                                }
                                if(seriesData.get("link")!=null) {
                                    mappedvalues.get(seriesName).add(new Value().setValue(Integer.valueOf(seriesData.get("value").toString()), seriesData.get("link").toString()));
                                }else {
                                    mappedvalues.get(seriesName).add(new Value().setValue(Integer.valueOf(seriesData.get("value").toString()), ""));
                                }
                            };
                        };
                        List<Map> transformedData = mappedvalues.keySet().stream().sorted().map(key->{
                            Map<String,Object>  data3 = new LinkedHashMap<>();
                            data3.put("seriesName",key);
                            data3.put("data",mappedvalues.get(key));
                            return data3;
                        }).collect(Collectors.toList());
                        StackedFusionChartData stackedFusionChartData = new StackedFusionChartData("#chart_ui_data", List.of(categoriesData),transformedData);
                        JSONArray jsonArray1 = new JSONArray();
                        jsonArray1.add(stackedFusionChartData);
                        dataDTO.setData(jsonArray1);
                        dataDTO.setChartItemDetails(chartItem);
                    }
                } else {
                    if(data1!=null) {
                        data.add(new ChartData(metrics.getMetricName(), metrics.getMetricValue(), null, null, data1.getChildren(), data1.getSeries()));
                    }
                    else{
                        data.add(new ChartData(metrics.getMetricName(), metrics.getMetricValue(), null, null, null, null));
                    }
                    if (data.size() > 0) {
                        Collections.sort(data, new SortByName());
                    }
                    dataDTO.setChartItemDetails(chartItem);
                    dataDTO.setData(data);
                }
            }
        }
        System.out.println(dataDTO);
        return dataDTO;
    }


    public IDChartItemDataDTO getMetricDataByORG(String id, String orgId, String dashboardName, ChartData data1) throws
            ParseException {

        System.out.println("*** ORG Data ***");
        IDChartItem chartItem = assertAndGet(id);
        System.out.println("chartItem -*-*-*- " + chartItem);

        List<ChartData> data = new ArrayList<>();
        IDChartItemDataDTO dataDTO = new IDChartItemDataDTO();
        List<ChartDataTrending> dataTrending = new ArrayList<>();

        Optional<MetricConfig> metricConfig = metricConfigRepository.findByMetricName(chartItem.getMetricName());
        System.err.println("$$$$$$$$$$$ - " + metricConfig);

        if (metricConfig.isPresent()) {
            MetricConfig metricConfig1 = metricConfig.get();
            String grouping = metricConfig1.getGrouping();
            String trending = metricConfig1.getTrending();
            String customFunction = metricConfig1.getCustomFunction();
            String customFunctionName = metricConfig1.getCustomFunctionName();

            //SourceMetrics metrics = metricRepo.findByOrgIdAndDashboardNameAndItemId(orgId,dashboardName,id);
            Optional<SourceMetrics> metrics1 = metricRepo.findByOrgIdAndDashboardNameAndItemIdAndMetricName(orgId,dashboardName,id, metricConfig1.getMetricName());
            System.out.println("Source Metrics is present : " + metrics1.isPresent());

            if (metrics1.isPresent()) {
                SourceMetrics metrics = metrics1.get();
                System.out.println("Source metrics fetched is : "+metrics);
                if ("yes".equalsIgnoreCase(grouping)) {
                    if(chartItem.getType().equalsIgnoreCase("bar-vertical-chart-fusion")){
                        String calculatedResults = metrics.getMetricValues().toJSONString();
                        JSONArray array = (JSONArray) new JSONParser().parse(calculatedResults);
                        for (int i = 0; i < array.size(); i++) {
                            JSONObject result = (JSONObject) array.get(i);
                            String linkValue = null;
                            if(result.get("link")!=null){
                                linkValue = result.get("link").toString();
                            }
                            else{
                                linkValue ="";
                            }
                            data.add(new ChartData(result.get("groupName").toString(), result.get("result"), result.get("groupName").toString(), linkValue, null, null));
                        }
                    }
                    else {
                        String calculatedResults = metrics.getMetricValues().toJSONString();
                        JSONArray array = (JSONArray) new JSONParser().parse(calculatedResults);
                        for (int i = 0; i < array.size(); i++) {
                            JSONObject result = (JSONObject) array.get(i);
                            data.add(new ChartData(result.get("groupName").toString(), result.get("result"), null, null, null, null));
                        }
                    }
                    if (data.size() > 0) {
                        Collections.sort(data, new SortByName());
                    }
                    dataDTO.setChartItemDetails(chartItem);
                    dataDTO.setData(data);
                } else if ("yes".equalsIgnoreCase(trending)) {
                    // String calculatedResults = metrics.getGroupedResult().toJSONString();
                    List<TrendingMetric> calculatedResults = metrics.getTrendingMetricValues();
                    SimpleDateFormat inputDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
                    calculatedResults.forEach(calculatedResult -> {
                        Date month = calculatedResult.getMonth();
                        Integer result = calculatedResult.getResult();
                        SimpleDateFormat outputDateFormat = new SimpleDateFormat("EEE MMM dd hh:mm:ss z yyyy");
                        //SimpleDateFormat outputDateFormat = new SimpleDateFormat("EEE d MMM, yyyy");
                        String outputDateString = outputDateFormat.format(month);
                        dataTrending.add(new ChartDataTrending(outputDateString, result));
                    });
                    dataDTO.setChartItemDetails(chartItem);
                    dataDTO.setData(dataTrending);
                } else if ("yes".equalsIgnoreCase(customFunction)) {
                    String calculatedResults = metrics.getMetricValues().toJSONString();
                    JSONArray array = (JSONArray) new JSONParser().parse(calculatedResults);
                    System.out.println("Calculates results ** " + array);
                    if (customFunctionName.equalsIgnoreCase("defect_ageing")) {
                        System.out.println("DEFECT AGEING FUNCTION ** ");
                        for (int i = 0; i < array.size(); i++) {
                            JSONObject result = (JSONObject) array.get(i);
                            data.add(new ChartData(result.get("groupName").toString(), result.get("result"), null, null, null, null));
                        }
                        if (data.size() > 0) {
                            Collections.sort(data, new SortByName());
                        }
                        dataDTO.setChartItemDetails(chartItem);
                        dataDTO.setData(data);
                    } else if (customFunctionName.equalsIgnoreCase("defect_ageing_agile")) {
                        System.out.println("DEFECT AGEING AGILE FUNCTION ** ");
                        for (int i = 0; i < array.size(); i++) {
                            JSONObject result = (JSONObject) array.get(i);
                            data.add(new ChartData(result.get("groupName").toString(), result.get("result"), null, null, null, null));
                        }
                        if (data.size() > 0) {
                            Collections.sort(data, new SortByName());
                        }
                        dataDTO.setChartItemDetails(chartItem);
                        dataDTO.setData(data);
                    } else if (customFunctionName.equalsIgnoreCase("defect_ageing_stack")) {
                        System.out.println("DEFECT AGEING STACK FUNCTION ** ");
                        for (int i = 0; i < array.size(); i++) {
                            JSONObject result = (JSONObject) array.get(i);
                            data.add(new ChartData(result.get("name").toString(), result.get("value"), result.get("label").toString(), null, null, (List<ChartData>) result.get("series")));
                        }
                        if (data.size() > 0) {
                            Collections.sort(data, new SortByName());
                        }
                        dataDTO.setChartItemDetails(chartItem);
                        dataDTO.setData(data);
                    }else if (customFunctionName.equalsIgnoreCase("execution_progress")) {
                        System.out.println("EXECUTION FUNCTION ** ");
                        for (int i = 0; i < array.size(); i++) {
                            JSONObject result = (JSONObject) array.get(i);
                            data.add(new ChartData(result.get("name").toString(), result.get("value"), result.get("label").toString(), null, null, (List<ChartData>) result.get("series")));
                        }
                        if (data.size() > 0) {
                            Collections.sort(data, new SortByName());
                        }
                        Map<String, List<Value>> mappedvalues = new HashMap<>();
                        Categories categoriesData = new Categories();
                        for(ChartData data2 :data){
                            Map<String,Integer> value = new HashMap<>();
                            categoriesData.getCategory().add(
                                    new Category().setLabel(data2.getName())
                            );

                            ListIterator seriesDataMap = data2.getSeries().listIterator();
                            while(seriesDataMap.hasNext()){
                                JSONObject  seriesData = (JSONObject) seriesDataMap.next();
                                String seriesName = seriesData.get("name").toString();
                                if(mappedvalues.get(seriesName) == null){
                                    mappedvalues.put(seriesName,new LinkedList<>());
                                }
                                if(seriesData.get("link")!=null) {
                                    mappedvalues.get(seriesName).add(new Value().setValue(Integer.valueOf(seriesData.get("value").toString()), seriesData.get("link").toString()));
                                }else {
                                    mappedvalues.get(seriesName).add(new Value().setValue(Integer.valueOf(seriesData.get("value").toString()), ""));
                                }
                            };
                        };
                        List<Map> transformedData = mappedvalues.keySet().stream().sorted().map(key->{
                            Map<String,Object>  data3 = new LinkedHashMap<>();
                            data3.put("seriesName",key);
                            data3.put("data",mappedvalues.get(key));
                            return data3;
                        }).collect(Collectors.toList());
                        StackedFusionChartData stackedFusionChartData = new StackedFusionChartData("#chart_ui_data", List.of(categoriesData),transformedData);
                        JSONArray jsonArray1 = new JSONArray();
                        jsonArray1.add(stackedFusionChartData);
                        dataDTO.setData(jsonArray1);
                        dataDTO.setChartItemDetails(chartItem);
                    }else if (customFunctionName.equalsIgnoreCase("quality_metrics")) {
                        System.out.println("QUALITY METRICS FUNCTION ** ");
                        for (int i = 0; i < array.size(); i++) {
                            JSONObject result = (JSONObject) array.get(i);
                            data.add(new ChartData(result.get("name").toString(), result.get("value"), result.get("label").toString(), null, null, (List<ChartData>) result.get("series")));
                        }
                        if (data.size() > 0) {
                            Collections.sort(data, new SortByName());
                        }
                        Map<String, List<Value>> mappedvalues = new HashMap<>();
                        Categories categoriesData = new Categories();
                        for(ChartData data2 :data){
                            Map<String,Integer> value = new HashMap<>();
                            categoriesData.getCategory().add(
                                    new Category().setLabel(data2.getName())
                            );

                            ListIterator seriesDataMap = data2.getSeries().listIterator();
                            while(seriesDataMap.hasNext()){
                                JSONObject  seriesData = (JSONObject) seriesDataMap.next();
                                String seriesName = seriesData.get("name").toString();
                                if(mappedvalues.get(seriesName) == null){
                                    mappedvalues.put(seriesName,new LinkedList<>());
                                }
                                if(seriesData.get("link")!=null) {
                                    mappedvalues.get(seriesName).add(new Value().setValue(Integer.valueOf(seriesData.get("value").toString()), seriesData.get("link").toString()));
                                }else {
                                    mappedvalues.get(seriesName).add(new Value().setValue(Integer.valueOf(seriesData.get("value").toString()), ""));
                                }
                            };
                        };
                        List<Map> transformedData = mappedvalues.keySet().stream().sorted().map(key->{
                            Map<String,Object>  data3 = new LinkedHashMap<>();
                            data3.put("seriesName",key);
                            data3.put("data",mappedvalues.get(key));
                            return data3;
                        }).collect(Collectors.toList());
                        StackedFusionChartData stackedFusionChartData = new StackedFusionChartData("#chart_ui_data", List.of(categoriesData),transformedData);
                        JSONArray jsonArray1 = new JSONArray();
                        jsonArray1.add(stackedFusionChartData);
                        dataDTO.setChartItemDetails(chartItem);
                        dataDTO.setData(jsonArray1);
                    }
                } else {
                    if(data1!=null) {
                        data.add(new ChartData(metrics.getMetricName(), metrics.getMetricValue(), null, null, data1.getChildren(), data1.getSeries()));
                    }
                    else{
                        data.add(new ChartData(metrics.getMetricName(), metrics.getMetricValue(), null, null, null, null));
                    }
                    if (data.size() > 0) {
                        Collections.sort(data, new SortByName());
                    }
                    dataDTO.setChartItemDetails(chartItem);
                    dataDTO.setData(data);
                }
            }
        }
        System.out.println(dataDTO);
        return dataDTO;
    }
}
