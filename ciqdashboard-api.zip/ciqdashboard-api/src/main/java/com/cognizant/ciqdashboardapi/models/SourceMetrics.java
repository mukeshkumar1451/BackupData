package com.cognizant.ciqdashboardapi.models;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;
import org.json.simple.JSONArray;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.Instant;
import java.util.List;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@Document(collection = "source_metrics")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class SourceMetrics {
    @Id
    private String id;
    private String toolType;
    private String metricName;
    private int metricValue;
    private String projectName;
    private String dashboardName;
    private String pageName;
    private String itemId;
    private Instant lastCalculatedDate;
    private String lobId;
    private String orgId;
    private String customFunction;
    private String customFunctionName;
    private String groupName;
    private String groupBy;
    private boolean isGrouping;
    private JSONArray groupedResult;
    // private JSONArray trendResult;
    private JSONArray metricValues;

    private List<TrendingMetric> trendingMetricValues;
}
