package com.cognizant.ciqdashboardapi.controllers;


import com.cognizant.ciqdashboardapi.models.CIQDashboardTemplate;
import com.cognizant.ciqdashboardapi.services.CIQDashboardTemplateService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/dashboard-template")
public class DashboardTemplateController {
    @Autowired
    CIQDashboardTemplateService service;

    @GetMapping("/get-all-templates/{category}")
    public List<CIQDashboardTemplate> getAllTemplates(@PathVariable("category") String category) throws Exception {
        System.out.println("$$$$$$$$$ category -- " + category);
        return service.getAllTemplates(category);
    }

    @GetMapping("/get-all-templates/")
    public List<CIQDashboardTemplate> getAllTemplates() throws Exception {

        return service.getAllTemplates();
    }
}
