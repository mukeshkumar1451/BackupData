package com.cognizant.collector.DatabaseCollector.controller;

import com.cognizant.collector.DatabaseCollector.service.DataTransferService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/data-transfer")
public class DataTransferController {

    @Autowired
    private DataTransferService dataTransferService;

    @PostMapping("/transfer")
    public String transferData(@RequestParam(value = "jiraProjectKey", required = true) String jiraProjectKey) {
        if (jiraProjectKey == null || jiraProjectKey.trim().isEmpty()) {
            return "Error: JiraProjectKey is required.";
        }

        try {
            System.out.println("Starting data transfer for Jira Project Key: " + jiraProjectKey);

            // Call the service to transfer data
            dataTransferService.transferAllCollections(jiraProjectKey);

            return "Data transfer completed for Jira Project Key: " + jiraProjectKey;
        } catch (Exception e) {
            e.printStackTrace();
            return "Error during data transfer: " + e.getMessage();
        }
    }
}
