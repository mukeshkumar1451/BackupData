package com.cognizant.collector.DatabaseCollector.Scheduler;





import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Date;

@Document(collection = "SchedulerInfo")
public class SchedulerInfo {
    private String collectionName;
    private String jiraProjectKey;
    private Date lastRun;
    private String status;

    // Constructors, getters, and setters

    public String getCollectionName() {
        return collectionName;
    }

    public void setCollectionName(String collectionName) {
        this.collectionName = collectionName;
    }

    public String getJiraProjectKey() {
        return jiraProjectKey;
    }

    public void setJiraProjectKey(String jiraProjectKey) {
        this.jiraProjectKey = jiraProjectKey;
    }

    public Date getLastRun() {
        return lastRun;
    }

    public void setLastRun(Date lastRun) {
        this.lastRun = lastRun;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }


}


