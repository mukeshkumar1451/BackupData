package com.cognizant.collector.DatabaseCollector;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DatabaseCollectorApplication {

	public static void main(String[] args) {
		SpringApplication.run(DatabaseCollectorApplication.class, args);
	}

}
